// ========== LOADER ==========
window.addEventListener('load', function() {
    setTimeout(() => {
        const loader = document.getElementById('pageLoader');
        if (loader) loader.classList.add('hidden');
    }, 1000);
});

// ========== SISTEMA DE AUDITORÍA LOCAL (FALLBACK) ==========
const usuariosAutorizados = ['admin', 'auditor'];
let auditoriaLogs = JSON.parse(localStorage.getItem('auditoriaLogs') || '[]');

function obtenerRol(usuario) {
    if (usuario === 'admin') return 'Administrador';
    if (usuario === 'auditor') return 'Auditor';
    return 'Comprador';
}

function registrarAuditoria(usuario, accion) {
    const ahora = new Date();
    const registro = {
        id: auditoriaLogs.length + 1,
        usuario: usuario,
        rol: obtenerRol(usuario),
        fecha: ahora.toLocaleDateString('es-ES'),
        hora: ahora.toLocaleTimeString('es-ES'),
        fechaHora: ahora.toISOString(),
        dispositivo: navigator.userAgent.includes('Mobile') ? '📱 Móvil' : '💻 Escritorio',
        accion: accion
    };
    auditoriaLogs.push(registro);
    localStorage.setItem('auditoriaLogs', JSON.stringify(auditoriaLogs));
}

function mostrarOcultarAuditoria(usuario) {
    const navAuditoria = document.querySelector('.nav-auditoria');
    if (navAuditoria) {
        navAuditoria.style.display = usuariosAutorizados.includes(usuario) ? 'block' : 'none';
    }
}

// ========== DATOS DE MOTOS (CON STOCK LOCAL) ==========
const motos = {
    jaguar: { 
        nombre: "Jaguar TR 150cc", precio: 1190, icono: "🔥", cilindrada: "150cc", categoria: "150",
        stock_2025: 5, stock_2026: 3,
        especificaciones: ["⚡ Motor: Monocilíndrico 150cc", "🔧 Tanque: 14 Litros", "⚙️ Transmisión: 5 velocidades", "🚀 Velocidad máxima: 100 km/h", "⛽ Parrilla: Trasera reforzada de fábrica", "🛑 Frenos: Disco (delantero) / Tambor (trasero)", "💨 Uso: Trabajo pesado / Mensajería"]
    },
    rex: { 
        nombre: "Rex TR 250cc", precio: 2150, icono: "🦖", cilindrada: "250cc", categoria: "250",
        stock_2025: 5, stock_2026: 3,
        especificaciones: ["⚡ Motor: 250cc Loncin (Cadena de tiempo)", "🔧 Transmisión: 6 velocidades", "⚙️ Suspensión: Monoshock trasero y barras reforzadas", "🚀 Iluminación: Full LED (Faro de profundidad)", "⛽ Tablero: Digital completo", "🛑 Frenos: Disco (delantero) / Tambor (trasero)", "💨 Extras: Asiento ergonómico de dos niveles"]
    },
    fox: { 
        nombre: "Fox TR 180cc", precio: 1840, icono: "🦊", cilindrada: "180cc", categoria: "180",
        stock_2025: 5, stock_2026: 3,
        especificaciones: ["⚡ Motor: 4 tiempos, monocilíndrico 180cc", "🔧 Potencia: 14.5 HP", "⚙️ Transmisión: 5 velocidades", "🚀 Velocidad máxima: 115 km/h", "⛽ Consumo: 32 km/litro", "🛑 Frenos: Disco (delantero) / Tambor (trasero)", "💨 Arranque: Eléctrico y patada"]
    },
    leon: { 
        nombre: "León TR 200cc", precio: 1420, icono: "🦁", cilindrada: "200cc", categoria: "200",
        stock_2025: 5, stock_2026: 3,
        especificaciones: ["⚡ Motor: OHC con balanceador (vibración reducida)", "🔧 Capacidad de Tanque: 17 Litros", "⚙️ Transmisión: 5 velocidades", "🚀 Luces: Full LED (Faro, stop y cruces)", "⛽ Tablero: Análogo con indicador de marcha", "🛑 Frenos: Disco (delantero) / Tambor (trasero)", "💨 Cauchos: 3.0-18 (D) / 110-90-16 (T)"]
    },
    r3x: { 
        nombre: "R3X 250cc", precio: 2790, icono: "🏁", cilindrada: "250cc", categoria: "250",
        stock_2025: 5, stock_2026: 3,
        especificaciones: ["⚡ Motor: Cadenillo de alto rendimiento", "🔧 Estilo: Deportiva / Touring", "⚙️ Transmisión: 6 velocidades", "🚀 Velocidad máxima: 135 km/h", "⛽ Seguridad: Frenos de disco en ambas ruedas", "🛑 Suspensión: Barras invertidas (delanteras)", "💨 Arranque: Eléctrico"]
    },
    rex150: { 
        nombre: "Rex TR 150cc", precio: 1499, icono: "🦖", cilindrada: "150cc", categoria: "150",
        stock_2025: 5, stock_2026: 3,
        especificaciones: ["⚡ Motor: 150cc Enduro / Doble Propósito", "🔧 Accesorios: Incluye casco V2 original", "⚙️ Transmisión: 5 velocidades", "🚀 Velocidad máxima: 105 km/h", "⛽ Tanque: Reforzado para uso rudo", "🛑 Frenos: Disco (delantero)", "💨 Arranque: Eléctrico y patada"]
    },
    tank3: { 
        nombre: "Tank III 180cc", precio: 2500, icono: "🛡️", cilindrada: "180cc", categoria: "180",
        stock_2025: 5, stock_2026: 3,
        especificaciones: ["⚡ Motor: 180cc Automático (Scooter)", "🔧 Diseño: Maxiscooter de lujo", "⚙️ Transmisión: Automática CVT", "🚀 Velocidad máxima: 110 km/h", "⛽ Comodidad: Asiento doble nivel ergonómico", "🛑 Frenos: Disco en ambas ruedas", "💨 Extras: Luces LED y tablero digital"]
    },
    tankTr180: { 
        nombre: "Tank TR 180cc", precio: 1920, icono: "🦾", cilindrada: "180cc", categoria: "180",
        stock_2025: 5, stock_2026: 3,
        especificaciones: ["⚡ Motor: 180cc Automática", "🔧 Uso: Urbano / Diario", "⚙️ Transmisión: Automática", "🚀 Velocidad máxima: 105 km/h", "⛽ Capacidad: Maletero bajo el asiento", "🛑 Frenos: Disco (delantero)", "💨 Sistema: Alarma de fábrica"]
    }
};

// ========== CARGA DE STOCK DESDE BASE DE DATOS ==========
let stockBD = null;

async function cargarStockDesdeBD() {
    try {
        const usuario = localStorage.getItem('usuarioActual');
        const usuarioId = localStorage.getItem('usuarioId');
        const rol = localStorage.getItem('rolActual');
        
        const response = await fetch(`backend.php?action=getStock&usuario=${encodeURIComponent(usuario || '')}&usuario_id=${usuarioId || 0}&rol=${encodeURIComponent(rol || '')}`);
        const data = await response.json();
        
        if (data.success && data.motos) {
            stockBD = data.motos;
            actualizarStockLocalDesdeBD(data.motos);
            actualizarBadgesStock();
        }
    } catch (error) {
        console.log('Usando stock local (sin conexión a BD):', error.message);
        stockBD = null;
        actualizarBadgesStock();
    }
}

function actualizarStockLocalDesdeBD(motosBD) {
    motosBD.forEach(motoBD => {
        if (motos[motoBD.id]) {
            motos[motoBD.id].precio = parseFloat(motoBD.precio_2025);
            motos[motoBD.id].precio_2025 = parseFloat(motoBD.precio_2025);
            motos[motoBD.id].precio_2026 = parseFloat(motoBD.precio_2026);
            motos[motoBD.id].stock_2025 = parseInt(motoBD.stock_2025);
            motos[motoBD.id].stock_2026 = parseInt(motoBD.stock_2026);
            motos[motoBD.id].nombre = motoBD.nombre;
        }
    });
}

function actualizarBadgesStock() {
    document.querySelectorAll('.modelo-badge').forEach(badge => {
        const card = badge.closest('.modelo-card-principal');
        if (card) {
            const motoId = Object.keys(motos).find(id => {
                const img = card.querySelector('img');
                return img && img.alt.includes(motos[id].nombre);
            });
            
            if (motoId && motos[motoId]) {
                const stock25 = motos[motoId].stock_2025 || 0;
                const stock26 = motos[motoId].stock_2026 || 0;
                badge.title = `📦 Stock 2025: ${stock25} | Stock 2026: ${stock26}`;
                
                // Agregar indicador visual de stock bajo
                if (stock25 <= 2 || stock26 <= 2) {
                    badge.style.background = '#e67e22';
                    badge.textContent = `${motos[motoId].icono} ⚠️`;
                }
                if (stock25 <= 0 && stock26 <= 0) {
                    badge.style.background = '#dc2626';
                    badge.textContent = '❌ AGOTADO';
                }
            }
        }
    });
}

function getPrecioConStock(motoId, anio) {
    const moto = motos[motoId];
    if (!moto) return { precio: 0, stock: 0, disponible: false };
    
    const stock = anio === '2025' ? (moto.stock_2025 || 0) : (moto.stock_2026 || 0);
    const precioBase = anio === '2025' ? (moto.precio_2025 || moto.precio) : (moto.precio_2026 || Math.round(moto.precio * 1.10));
    
    return {
        precio: precioBase,
        stock: stock,
        disponible: stock > 0
    };
}

async function registrarApartadoBD(motoId, anio, plan, metodoPago, montoTotal, montoApartado, cuotas, valorCuota) {
    try {
        const usuario = localStorage.getItem('usuarioActual');
        const usuarioId = localStorage.getItem('usuarioId');
        const rol = localStorage.getItem('rolActual');
        
        const response = await fetch('backend.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=apartado&usuario_id=${usuarioId}&usuario=${encodeURIComponent(usuario)}&rol=${encodeURIComponent(rol)}&moto_id=${motoId}&anio=${anio}&plan=${plan}&metodo_pago=${metodoPago}&monto_total=${montoTotal}&monto_apartado=${montoApartado}&cuotas=${cuotas}&valor_cuota=${valorCuota}`
        });
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.log('Error al registrar apartado en BD:', error);
        // Reducir stock local como fallback
        if (motos[motoId]) {
            const stockField = anio === '2025' ? 'stock_2025' : 'stock_2026';
            if (motos[motoId][stockField] > 0) {
                motos[motoId][stockField]--;
            }
        }
        return { success: true, local: true };
    }
}

// ========== TOGGLE PASSWORD ==========
document.getElementById('togglePassword')?.addEventListener('click', function() {
    const passwordInput = document.getElementById('loginPass');
    const icon = this.querySelector('i');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
});

// ========== LOGIN ==========
const loginOverlay = document.getElementById('loginOverlay');
const mainContent = document.getElementById('mainContent');
const btnLogin = document.getElementById('btnLogin');
const btnLogout = document.getElementById('btnLogout');
const loginUser = document.getElementById('loginUser');
const loginPass = document.getElementById('loginPass');
const loginError = document.getElementById('loginError');
const rememberMe = document.getElementById('rememberMe');

if (localStorage.getItem('rememberedUser')) {
    loginUser.value = localStorage.getItem('rememberedUser');
    rememberMe.checked = true;
}

// ========== LOGIN PRINCIPAL (INTENTA BD, FALLBACK A LOCAL) ==========
async function validarLogin() {
    const user = loginUser.value.trim();
    const pass = loginPass.value;
    
    if (!user || !pass) {
        loginError.style.display = 'block';
        setTimeout(() => loginError.style.display = 'none', 3000);
        return;
    }
    
    try {
        const response = await fetch('backend.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=login&usuario=${encodeURIComponent(user)}&password=${encodeURIComponent(pass)}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            loginExitoso(data.usuario, data.rol, data.nombre_completo, data.usuario_id);
        } else {
            // Intentar login local
            validarLoginLocal(user, pass);
        }
    } catch (error) {
        console.log('Sin conexión a BD, usando login local:', error.message);
        validarLoginLocal(user, pass);
    }
}

function validarLoginLocal(user, pass) {
    let credencialesValidas = false;
    let rol = 'Comprador';
    let nombreCompleto = 'Comprador';
    
    if (user === "admin" && pass === "1234") {
        credencialesValidas = true;
        rol = 'Administrador';
        nombreCompleto = 'Administrador Toro';
    } else if (user === "auditor" && pass === "5678") {
        credencialesValidas = true;
        rol = 'Auditor';
        nombreCompleto = 'Auditor Toro';
    } else if (user === "comprador" && pass === "0000") {
        credencialesValidas = true;
        rol = 'Comprador';
        nombreCompleto = 'Cliente Demo';
    }
    
    if (credencialesValidas) {
        loginExitoso(user, rol, nombreCompleto, 0);
    } else {
        loginFallido();
    }
}

function loginExitoso(usuario, rol, nombreCompleto, usuarioId) {
    loginError.style.display = 'none';
    loginOverlay.style.display = 'none';
    mainContent.classList.add('visible');
    
    if (rememberMe.checked) {
        localStorage.setItem('rememberedUser', usuario);
    } else {
        localStorage.removeItem('rememberedUser');
    }
    
    localStorage.setItem('sesionActiva', 'true');
    localStorage.setItem('usuarioActual', usuario);
    localStorage.setItem('rolActual', rol);
    localStorage.setItem('usuarioId', usuarioId);
    document.getElementById('userName').textContent = nombreCompleto || rol;
    
    registrarAuditoria(usuario, 'login');
    mostrarOcultarAuditoria(usuario);
    cargarStockDesdeBD();
    
    mostrarNotificacion('¡Bienvenido ' + (nombreCompleto || rol) + '!', 'exito');
    loginUser.value = '';
    loginPass.value = '';
}

function loginFallido() {
    loginError.style.display = 'block';
    loginPass.value = '';
    loginError.style.animation = 'none';
    setTimeout(() => loginError.style.animation = 'shake 0.5s ease', 10);
    setTimeout(() => loginError.style.display = 'none', 3000);
}

// ========== LOGOUT ==========
async function cerrarSesion() {
    const usuarioActual = localStorage.getItem('usuarioActual') || 'Usuario';
    const usuarioId = localStorage.getItem('usuarioId') || 0;
    const rol = localStorage.getItem('rolActual') || 'Comprador';
    
    registrarAuditoria(usuarioActual, 'logout');
    
    // Intentar registrar logout en BD
    try {
        await fetch('backend.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=logout&usuario_id=${usuarioId}&usuario=${encodeURIComponent(usuarioActual)}&rol=${encodeURIComponent(rol)}`
        });
    } catch (error) {
        console.log('Logout local (sin BD)');
    }
    
    mainContent.classList.remove('visible');
    loginOverlay.style.display = 'flex';
    localStorage.removeItem('sesionActiva');
    localStorage.removeItem('usuarioActual');
    localStorage.removeItem('rolActual');
    localStorage.removeItem('usuarioId');
    mostrarNotificacion('Sesión cerrada correctamente', 'info');
}

// ========== NOTIFICACIONES ==========
function mostrarNotificacion(mensaje, tipo) {
    const notificacion = document.createElement('div');
    notificacion.className = 'notificacion';
    const colores = { exito: '#10b981', info: '#3b82f6', error: '#ef4444', warning: '#f59e0b' };
    notificacion.style.background = colores[tipo] || colores.info;
    notificacion.style.color = 'white';
    const iconos = { exito: 'fa-check-circle', info: 'fa-info-circle', error: 'fa-exclamation-triangle', warning: 'fa-exclamation-circle' };
    notificacion.innerHTML = `<i class="fas ${iconos[tipo]}"></i><span>${mensaje}</span>`;
    document.body.appendChild(notificacion);
    setTimeout(() => {
        notificacion.style.animation = 'slideOutRight 0.5s ease forwards';
        setTimeout(() => notificacion.remove(), 500);
    }, 3000);
}

// ========== EVENT LISTENERS ==========
btnLogin.addEventListener('click', validarLogin);
btnLogout.addEventListener('click', cerrarSesion);
loginUser.addEventListener('keypress', (e) => { if (e.key === 'Enter') validarLogin(); });
loginPass.addEventListener('keypress', (e) => { if (e.key === 'Enter') validarLogin(); });

// Restaurar sesión
if (localStorage.getItem('sesionActiva') === 'true') {
    loginOverlay.style.display = 'none';
    mainContent.classList.add('visible');
    const usuarioGuardado = localStorage.getItem('usuarioActual');
    if (usuarioGuardado) {
        document.getElementById('userName').textContent = obtenerRol(usuarioGuardado);
        mostrarOcultarAuditoria(usuarioGuardado);
        cargarStockDesdeBD();
    }
}

// ========== FUNCIONES DEL MENÚ ==========
function mostrarPagina(pagina) {
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.getElementById(`page-${pagina}`).classList.add('active');
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === pagina) item.classList.add('active');
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    if (pagina === 'auditoria') cargarTablaAuditoria();
    if (pagina === 'modelos') actualizarBadgesStock();
}

// ========== FILTROS DE MODELOS ==========
let filtroActual = 'all';
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        filtroActual = this.dataset.filter;
        generarModelosGrid();
    });
});

// ========== GENERAR TARJETAS DE MODELOS ==========
function generarModelosGrid() {
    const grid = document.getElementById('modelosGridPrincipal');
    if (!grid) return;
    
    const modelosLista = [
        { id: 'jaguar', nombre: 'Jaguar TR 150cc', precio: motos.jaguar.precio_2025 || motos.jaguar.precio, icono: '🔥', categoria: '150', cilindrada: '150cc' },
        { id: 'rex', nombre: 'Rex TR 250cc', precio: motos.rex.precio_2025 || motos.rex.precio, icono: '🦖', categoria: '250', cilindrada: '250cc' },
        { id: 'fox', nombre: 'Fox TR 180cc', precio: motos.fox.precio_2025 || motos.fox.precio, icono: '🦊', categoria: '180', cilindrada: '180cc' },
        { id: 'leon', nombre: 'León TR 200cc', precio: motos.leon.precio_2025 || motos.leon.precio, icono: '🦁', categoria: '200', cilindrada: '200cc' },
        { id: 'r3x', nombre: 'R3X 250cc', precio: motos.r3x.precio_2025 || motos.r3x.precio, icono: '🏁', categoria: '250', cilindrada: '250cc' },
        { id: 'rex150', nombre: 'Rex TR 150cc', precio: motos.rex150.precio_2025 || motos.rex150.precio, icono: '🦖', categoria: '150', cilindrada: '150cc' },
        { id: 'tank3', nombre: 'Tank III 180cc', precio: motos.tank3.precio_2025 || motos.tank3.precio, icono: '🛡️', categoria: '180', cilindrada: '180cc' },
        { id: 'tankTr180', nombre: 'Tank TR 180cc', precio: motos.tankTr180.precio_2025 || motos.tankTr180.precio, icono: '🦾', categoria: '180', cilindrada: '180cc' }
    ];
    
    const modelosFiltrados = filtroActual === 'all' ? modelosLista : modelosLista.filter(m => m.categoria === filtroActual);
    const imagenesModelos = { jaguar: "modelos/Jaguar.jpg", rex: "modelos/rextr250.jpg", fox: "modelos/fox.jpg", leon: "modelos/leon.jpg", r3x: "modelos/r3x.jpg", rex150: "modelos/rex150.jpg", tank3: "modelos/tank3.jpg", tankTr180: "modelos/tanktr180.jpg" };
    
    let html = '';
    modelosFiltrados.forEach(moto => {
        const financiamiento = Math.ceil(moto.precio / 12);
        const imagenMoto = imagenesModelos[moto.id] || `modelos/${moto.id}.jpg`;
        const stockInfo = motos[moto.id];
        const stock25 = stockInfo ? (stockInfo.stock_2025 || 0) : 0;
        const stock26 = stockInfo ? (stockInfo.stock_2026 || 0) : 0;
        
        html += `
        <div class="modelo-card-principal" onclick="verDetalleMoto('${moto.id}')" data-moto-id="${moto.id}">
            <div class="modelo-img-principal">
                <img src="${imagenMoto}" alt="${moto.nombre}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <i class="fas fa-motorcycle" style="display: none; font-size: 50px; color: #8B0000;"></i>
                <span class="modelo-badge" title="📦 Stock 2025: ${stock25} | Stock 2026: ${stock26}">${moto.icono} ${moto.cilindrada}</span>
            </div>
            <div class="modelo-info-principal">
                <div class="modelo-marca">MOTOS TORO</div>
                <h3>${moto.nombre}</h3>
                <div class="modelo-especificaciones-mini">
                    <span class="espec-item"><i class="fas fa-tachometer-alt"></i> ${moto.cilindrada}</span>
                    <span class="espec-item"><i class="fas fa-box"></i> Stock: ${stock25 + stock26}</span>
                </div>
                <div class="modelo-precio-principal">
                    <div class="precio-valor">$${moto.precio} <small>USD</small></div>
                    <div class="precio-financiamiento">Desde $${financiamiento}/mes</div>
                </div>
                <button class="btn-detalles" onclick="event.stopPropagation(); verDetalleMoto('${moto.id}')">Ver detalles <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>`;
    });
    
    grid.innerHTML = html || '<p style="text-align: center; grid-column: 1/-1;">No hay modelos en esta categoría</p>';
}

// ========== VER DETALLE DE MOTO ==========
function verDetalleMoto(motoId) {
    const moto = motos[motoId];
    if (!moto) return;
    
    const imagenesModelos = { jaguar: "modelos/Jaguar.jpg", rex: "modelos/rextr250.jpg", fox: "modelos/fox.jpg", leon: "modelos/leon.jpg", r3x: "modelos/r3x.jpg", rex150: "modelos/rex150.jpg", tank3: "modelos/tank3.jpg", tankTr180: "modelos/tanktr180.jpg" };
    const imagenMoto = imagenesModelos[motoId] || "modelos/default.jpg";
    const stock25 = moto.stock_2025 || 0;
    const stock26 = moto.stock_2026 || 0;
    
    let detallePage = document.getElementById(`page-detalle-${motoId}`);
    if (!detallePage) {
        detallePage = document.createElement('div');
        detallePage.id = `page-detalle-${motoId}`;
        detallePage.className = 'page';
        detallePage.innerHTML = `
        <button class="btn-volver" onclick="volverAModelos()"><i class="fas fa-arrow-left"></i> Volver a Modelos</button>
        <div class="specs-container">
            <div class="specs-content">
                <div class="specs-info">
                    <h2 class="specs-title">${moto.nombre}</h2>
                    <div class="stock-info-detalle">
                        <span class="stock-badge ${stock25 > 0 ? 'disponible' : 'agotado'}">📦 2025: ${stock25 > 0 ? stock25 + ' disponibles' : 'Agotado'}</span>
                        <span class="stock-badge ${stock26 > 0 ? 'disponible' : 'agotado'}">📦 2026: ${stock26 > 0 ? stock26 + ' disponibles' : 'Agotado'}</span>
                    </div>
                    <ul class="specs-list">
                        ${moto.especificaciones.map(esp => {
                            let icono = 'fa-circle';
                            if (esp.includes('Motor')) icono = 'fa-bolt';
                            else if (esp.includes('Potencia')||esp.includes('Tanque')||esp.includes('Capacidad')||esp.includes('Accesorios')||esp.includes('Diseño')||esp.includes('Estilo')) icono = 'fa-wrench';
                            else if (esp.includes('Transmisión')) icono = 'fa-cog';
                            else if (esp.includes('Velocidad')||esp.includes('Luces')||esp.includes('Iluminación')) icono = 'fa-rocket';
                            else if (esp.includes('Consumo')||esp.includes('Tablero')) icono = 'fa-gas-pump';
                            else if (esp.includes('Frenos')||esp.includes('Seguridad')) icono = 'fa-dot-circle';
                            else if (esp.includes('Arranque')||esp.includes('Suspensión')||esp.includes('Extras')||esp.includes('Sistema')||esp.includes('Cauchos')||esp.includes('Comodidad')||esp.includes('Uso')||esp.includes('Parrilla')) icono = 'fa-hand-sparkles';
                            return `<li><i class="fas ${icono}"></i> ${esp}</li>`;
                        }).join('')}
                    </ul>
                </div>
                <div class="specs-image-wrapper">
                    <div class="image-platform">
                        <img src="${imagenMoto}" alt="${moto.nombre}" class="moto-float" onerror="this.src='modelos/default.jpg'">
                    </div>
                </div>
            </div>
        </div>
        <button class="btn-apartar" onclick="irAFinanciamientoConMoto('${motoId}')"><i class="fas fa-hand-holding-usd"></i> APARTAR ESTA MOTO</button>`;
        document.querySelector('.page-container').appendChild(detallePage);
    }
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    detallePage.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function volverAModelos() { mostrarPagina('modelos'); }

// ========== FINANCIAMIENTO ==========
let planSeleccionado = null, metodoPagoSeleccionado = null, motoSeleccionadaParaFinanciamiento = null, anioModeloSeleccionado = '2025';
const planesFinanciamiento = { basico: { nombre: "Plan Básico", apartado: 150, cuotas: 12, interes: 0 }, premium: { nombre: "Plan Premium", apartado: 300, cuotas: 24, interes: 5 } };
const metodosPago = { transferencia: { nombre: "Transferencia Bancaria", icono: "🏦" }, movil: { nombre: "Pago Móvil", icono: "📱" }, efectivo: { nombre: "Efectivo", icono: "💵" }, tarjeta: { nombre: "Tarjeta", icono: "💳" } };

function irAFinanciamientoConMoto(motoId) {
    motoSeleccionadaParaFinanciamiento = motos[motoId];
    motoSeleccionadaParaFinanciamiento.motoId = motoId;
    mostrarPagina('financiamiento');
    
    const stockInfo = getPrecioConStock(motoId, '2025');
    if (!stockInfo.disponible) {
        mostrarNotificacion('⚠️ Stock bajo para modelo 2025. Considere modelo 2026.', 'warning');
    }
    mostrarNotificacion(`Moto seleccionada: ${motoSeleccionadaParaFinanciamiento.nombre}`, 'exito');
}

function seleccionarPlan(plan) {
    planSeleccionado = plan;
    document.querySelectorAll('.financing-card.basic, .financing-card.premium').forEach(c => c.classList.remove('seleccionado'));
    const card = document.querySelector(`.financing-card.${plan}`);
    if (card) card.classList.add('seleccionado');
    mostrarNotificacion(`Plan ${planesFinanciamiento[plan].nombre} seleccionado`, 'exito');
    if (metodoPagoSeleccionado && motoSeleccionadaParaFinanciamiento) mostrarResumenFinanciamiento();
}

function seleccionarMetodoPago(metodo) {
    metodoPagoSeleccionado = metodo;
    document.querySelectorAll('.payment-methods span').forEach(s => s.classList.remove('seleccionado'));
    if (event && event.target) {
        const span = event.target.closest('span');
        if (span) span.classList.add('seleccionado');
    }
    mostrarNotificacion(`Método: ${metodosPago[metodo].nombre}`, 'exito');
    if (planSeleccionado && motoSeleccionadaParaFinanciamiento) mostrarResumenFinanciamiento();
}

function seleccionarAnioModelo(anio) {
    anioModeloSeleccionado = anio;
    document.querySelectorAll('.anio-btn-interno').forEach(btn => btn.classList.remove('active'));
    const btnSeleccionado = document.querySelector(`.anio-btn-interno[data-anio="${anio}"]`);
    if (btnSeleccionado) btnSeleccionado.classList.add('active');
    
    // Verificar stock
    if (motoSeleccionadaParaFinanciamiento) {
        const motoId = motoSeleccionadaParaFinanciamiento.motoId;
        const stockInfo = getPrecioConStock(motoId, anio);
        if (!stockInfo.disponible) {
            mostrarNotificacion('⚠️ ¡Stock agotado para este año! Seleccione otro año.', 'warning');
        }
    }
    
    mostrarNotificacion(`Año seleccionado: Modelo ${anio}${anio === '2026' ? ' (+10%)' : ''}`, 'info');
    if (motoSeleccionadaParaFinanciamiento && planSeleccionado && metodoPagoSeleccionado) mostrarResumenFinanciamiento();
}

function mostrarResumenFinanciamiento() {
    if (!motoSeleccionadaParaFinanciamiento) { mostrarNotificacion('Selecciona una moto primero', 'warning'); return; }
    
    const planData = planesFinanciamiento[planSeleccionado];
    const metodoData = metodosPago[metodoPagoSeleccionado];
    const motoId = motoSeleccionadaParaFinanciamiento.motoId;
    
    // Obtener precio según stock y año
    const stockInfo = getPrecioConStock(motoId, anioModeloSeleccionado);
    let precioBase = stockInfo.precio;
    let incrementoAnio = 0;
    
    if (anioModeloSeleccionado === '2026') {
        incrementoAnio = Math.round((motos[motoId].precio_2025 || motos[motoId].precio) * 0.10);
    }
    
    const montoApartado = planData.apartado;
    const cuotasMensuales = Math.ceil((precioBase - montoApartado) / planData.cuotas);
    
    const imagenesModelos = { jaguar: "modelos/Jaguar.jpg", rex: "modelos/rextr250.jpg", fox: "modelos/fox.jpg", leon: "modelos/leon.jpg", r3x: "modelos/r3x.jpg", rex150: "modelos/rex150.jpg", tank3: "modelos/tank3.jpg", tankTr180: "modelos/tanktr180.jpg" };
    const imagenMoto = imagenesModelos[motoId] || 'modelos/default.jpg';
    
    const resumenHTML = `
    <div class="resumen-contenido">
        <div class="resumen-datos">
            <div class="resumen-item"><span><i class="fas fa-tag"></i> Precio base:</span><strong>$${motos[motoId].precio_2025 || motos[motoId].precio} USD</strong></div>
            ${anioModeloSeleccionado === '2026' ? `<div class="resumen-item incremento"><span><i class="fas fa-plus-circle"></i> Incremento modelo 2026:</span><strong>+$${incrementoAnio} USD (10%)</strong></div>` : ''}
            <div class="resumen-item precio-final"><span><i class="fas fa-money-bill-wave"></i> Precio final:</span><strong>$${precioBase} USD</strong></div>
            <div class="resumen-item"><span><i class="fas fa-box"></i> Stock disponible:</span><strong style="color: ${stockInfo.disponible ? '#10b981' : '#dc2626'}">${stockInfo.stock} unidades</strong></div>
            <div class="resumen-item"><span><i class="fas fa-file-alt"></i> Plan seleccionado:</span><strong>${planData.nombre}</strong></div>
            <div class="resumen-item"><span><i class="fas fa-hand-holding-usd"></i> Monto de apartado:</span><strong>$${planData.apartado} USD</strong></div>
            <div class="resumen-item"><span><i class="fas fa-calendar-alt"></i> Número de cuotas:</span><strong>${planData.cuotas} cuotas</strong></div>
            <div class="resumen-item"><span><i class="fas fa-calculator"></i> Valor de cada cuota:</span><strong>$${cuotasMensuales} USD</strong></div>
            <div class="resumen-item"><span><i class="fas fa-credit-card"></i> Método de pago:</span><strong>${metodoData.nombre} ${metodoData.icono}</strong></div>
            ${planData.interes > 0 ? `<div class="resumen-item"><span><i class="fas fa-percentage"></i> Interés aplicado:</span><strong>${planData.interes}%</strong></div>` : ''}
            <div class="resumen-item total"><span><i class="fas fa-check-circle"></i> Total a pagar:</span><strong>$${precioBase} USD</strong></div>
        </div>
        <div class="resumen-moto-card">
            <img src="${imagenMoto}" alt="${motoSeleccionadaParaFinanciamiento.nombre}" class="resumen-moto-img" onerror="this.src='modelos/default.jpg'">
            <div class="resumen-moto-info">
                <h4>${motoSeleccionadaParaFinanciamiento.nombre}</h4>
                <div class="resumen-moto-detalles">
                    <span><i class="fas fa-calendar"></i> Año: ${anioModeloSeleccionado}</span>
                    <span><i class="fas fa-tachometer-alt"></i> ${motoSeleccionadaParaFinanciamiento.cilindrada}</span>
                    <span style="color: ${stockInfo.disponible ? '#10b981' : '#dc2626'}"><i class="fas fa-box"></i> Stock: ${stockInfo.stock}</span>
                </div>
            </div>
        </div>
    </div>`;
    
    document.getElementById('resumen-contenido').innerHTML = resumenHTML;
    document.getElementById('financiamiento-resumen').style.display = 'block';
    document.getElementById('financiamiento-resumen').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

async function confirmarFinanciamiento() {
    if (!motoSeleccionadaParaFinanciamiento) { mostrarNotificacion('Error: No hay una moto seleccionada', 'error'); return; }
    
    const planData = planesFinanciamiento[planSeleccionado];
    const metodoData = metodosPago[metodoPagoSeleccionado];
    const motoId = motoSeleccionadaParaFinanciamiento.motoId;
    
    // Verificar stock antes de confirmar
    const stockInfo = getPrecioConStock(motoId, anioModeloSeleccionado);
    if (!stockInfo.disponible) {
        mostrarNotificacion('❌ No hay stock disponible para este modelo y año', 'error');
        return;
    }
    
    let precioBase = stockInfo.precio;
    let incrementoAnio = 0;
    if (anioModeloSeleccionado === '2026') {
        incrementoAnio = Math.round((motos[motoId].precio_2025 || motos[motoId].precio) * 0.10);
    }
    
    const fecha = new Date();
    const fechaApartado = fecha.toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    fecha.setDate(fecha.getDate() + 30);
    const fechaLimite = fecha.toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    const numeroFactura = 'FT-' + new Date().getFullYear() + '-' + Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    const montoApartado = planData.apartado;
    const cuotasMensuales = Math.ceil((precioBase - montoApartado) / planData.cuotas);
    const saldoPendiente = precioBase - montoApartado;
    
    // Registrar apartado en BD
    const resultadoBD = await registrarApartadoBD(motoId, anioModeloSeleccionado, planSeleccionado, metodoData.nombre, precioBase, montoApartado, planData.cuotas, cuotasMensuales);
    
    const facturaHTML = `
        <div class="factura-linea"><span>📄 N° Factura:</span><strong>${numeroFactura}</strong></div>
        <div class="factura-linea"><span>📅 Fecha de apartado:</span><strong>${fechaApartado}</strong></div>
        <div class="factura-linea"><span>🏍️ Modelo:</span><strong>${motoSeleccionadaParaFinanciamiento.nombre}</strong></div>
        <div class="factura-linea"><span>📅 Año del modelo:</span><strong>${anioModeloSeleccionado}</strong></div>
        <div class="factura-linea"><span>⚡ Cilindrada:</span><strong>${motoSeleccionadaParaFinanciamiento.cilindrada}</strong></div>
        <div class="factura-linea"><span>💰 Precio base:</span><strong>$${motos[motoId].precio_2025 || motos[motoId].precio} USD</strong></div>
        ${anioModeloSeleccionado === '2026' ? `<div class="factura-linea" style="color: #e67e22;"><span>📈 Incremento modelo 2026 (10%):</span><strong>+$${incrementoAnio} USD</strong></div>` : ''}
        <div class="factura-linea"><span>💵 Precio final:</span><strong>$${precioBase} USD</strong></div>
        <div class="factura-linea"><span>📦 Stock restante:</span><strong>${stockInfo.stock - 1} unidades</strong></div>
        <div class="factura-linea"><span>📋 Plan seleccionado:</span><strong>${planData.nombre}</strong></div>
        <div class="factura-linea"><span>💳 Monto de apartado:</span><strong>$${montoApartado} USD</strong></div>
        <div class="factura-linea"><span>📊 Saldo pendiente:</span><strong>$${saldoPendiente} USD</strong></div>
        <div class="factura-linea"><span>📅 Número de cuotas:</span><strong>${planData.cuotas} cuotas</strong></div>
        <div class="factura-linea"><span>💲 Valor de cada cuota:</span><strong>$${cuotasMensuales} USD</strong></div>
        <div class="factura-linea"><span>💳 Método de pago:</span><strong>${metodoData.nombre} ${metodoData.icono}</strong></div>
        ${planData.interes > 0 ? `<div class="factura-linea"><span>📈 Interés aplicado:</span><strong>${planData.interes}% anual</strong></div>` : ''}
        <div class="factura-linea"><span>⏰ Fecha límite de pago del apartado:</span><strong>${fechaLimite}</strong></div>
        <div class="factura-linea total"><span>🎉 TOTAL A PAGAR:</span><strong>$${precioBase} USD</strong></div>
        <div class="factura-linea total"><span>✅ Estado:</span><strong style="color:#10b981">¡APARTADO EXITOSO! ✅</strong></div>
        <div class="factura-nota"><i class="fas fa-info-circle"></i><span>Presente esta factura al momento de retirar su moto. El saldo pendiente se cancela en ${planData.cuotas} cuotas.</span></div>
    `;
    
    document.getElementById('factura-contenido').innerHTML = facturaHTML;
    document.getElementById('financiamiento-resumen').style.display = 'none';
    document.getElementById('factura-final').style.display = 'block';
    
    // Actualizar badges de stock
    if (motos[motoId]) {
        const stockField = anioModeloSeleccionado === '2025' ? 'stock_2025' : 'stock_2026';
        if (motos[motoId][stockField] > 0) motos[motoId][stockField]--;
    }
    actualizarBadgesStock();
    
    mostrarNotificacion('¡Financiamiento aprobado! Factura generada exitosamente', 'exito');
    document.getElementById('factura-final').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function cancelarFinanciamiento() {
    planSeleccionado = null;
    metodoPagoSeleccionado = null;
    document.getElementById('financiamiento-resumen').style.display = 'none';
    document.querySelectorAll('.financing-card').forEach(c => c.classList.remove('seleccionado'));
    document.querySelectorAll('.payment-methods span').forEach(s => s.classList.remove('seleccionado'));
    mostrarNotificacion('Financiamiento cancelado', 'info');
}

function imprimirFactura() { window.print(); }

function regresarAlMenu() {
    planSeleccionado = null;
    metodoPagoSeleccionado = null;
    motoSeleccionadaParaFinanciamiento = null;
    document.getElementById('factura-final').style.display = 'none';
    document.getElementById('financiamiento-resumen').style.display = 'none';
    mostrarPagina('inicio');
    mostrarNotificacion('Regresando al menú', 'info');
}

// ========== AUDITORÍA ==========
async function cargarTablaAuditoria() {
    const tbody = document.getElementById('auditoriaTablaBody');
    if (!tbody) return;
    
    // Intentar cargar desde BD
    try {
        const response = await fetch('backend.php?action=getAuditoria');
        const data = await response.json();
        
        if (data.success && data.logs) {
            mostrarAuditoriaEnTabla(data.logs, tbody);
            actualizarEstadisticas(data.logs);
            return;
        }
    } catch (error) {
        console.log('Usando auditoría local');
    }
    
    // Fallback local
    const logsOrdenados = [...auditoriaLogs].reverse();
    mostrarAuditoriaEnTabla(logsOrdenados, tbody);
    actualizarEstadisticas(auditoriaLogs);
}

function mostrarAuditoriaEnTabla(logs, tbody) {
    if (logs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="sin-datos"><i class="fas fa-inbox"></i>No hay registros de auditoría</td></tr>`;
    } else {
        tbody.innerHTML = logs.map(log => `
            <tr>
                <td>#${log.id}</td>
                <td><strong>${log.usuario_nombre || log.usuario}</strong></td>
                <td><span class="auditoria-badge-rol ${(log.rol || '').toLowerCase()}">${log.rol}</span></td>
                <td>${log.fecha || new Date(log.fecha_hora).toLocaleDateString('es-ES')} - ${log.hora || new Date(log.fecha_hora).toLocaleTimeString('es-ES')}</td>
                <td>${log.dispositivo}</td>
                <td><span class="auditoria-badge-accion ${log.accion}">${log.accion === 'login' ? '✅ Ingreso' : log.accion === 'logout' ? '🚪 Salida' : '📋 ' + log.accion}</span></td>
            </tr>
        `).join('');
    }
}

function actualizarEstadisticas(logs) {
    const totalUsuariosEl = document.getElementById('totalUsuarios');
    const totalAccesosEl = document.getElementById('totalAccesos');
    const accesosHoyEl = document.getElementById('accesosHoy');
    
    if (!totalUsuariosEl) return;
    
    const usuariosUnicos = [...new Set(logs.map(log => log.usuario_nombre || log.usuario))];
    totalUsuariosEl.textContent = usuariosUnicos.length;
    totalAccesosEl.textContent = logs.length;
    
    const hoy = new Date().toLocaleDateString('es-ES');
    const accesosHoy = logs.filter(log => {
        const fechaLog = log.fecha || new Date(log.fecha_hora).toLocaleDateString('es-ES');
        return fechaLog === hoy;
    });
    accesosHoyEl.textContent = accesosHoy.length;
}

function filtrarAuditoria() {
    const filtroUsuario = document.getElementById('filtroUsuario').value.toLowerCase();
    const filtroFecha = document.getElementById('filtroFecha').value;
    const tbody = document.getElementById('auditoriaTablaBody');
    
    let logsFiltrados = [...auditoriaLogs].reverse();
    
    if (filtroUsuario) {
        logsFiltrados = logsFiltrados.filter(log => log.usuario.toLowerCase().includes(filtroUsuario));
    }
    
    if (filtroFecha) {
        const fechaBuscada = new Date(filtroFecha + 'T00:00:00').toLocaleDateString('es-ES');
        logsFiltrados = logsFiltrados.filter(log => log.fecha === fechaBuscada);
    }
    
    mostrarAuditoriaEnTabla(logsFiltrados, tbody);
}

function limpiarFiltros() {
    document.getElementById('filtroUsuario').value = '';
    document.getElementById('filtroFecha').value = '';
    cargarTablaAuditoria();
}

function exportarAuditoria() {
    let csv = 'ID,Usuario,Rol,Fecha,Hora,Dispositivo,Acción\n';
    auditoriaLogs.forEach(log => {
        csv += `${log.id},"${log.usuario}","${log.rol}","${log.fecha}","${log.hora}","${log.dispositivo}","${log.accion}"\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `auditoria_motos_toro_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
}

// ========== STOCK INFO EN DETALLE - AGREGAR AL CSS ==========
// Agregar estos estilos al CSS para los badges de stock

// ========== INICIALIZAR ==========
generarModelosGrid();

document.addEventListener('DOMContentLoaded', function() { 
    const btn2025 = document.querySelector('.anio-btn-interno[data-anio="2025"]'); 
    if (btn2025) btn2025.classList.add('active'); 
    anioModeloSeleccionado = '2025';
    
    const usuarioGuardado = localStorage.getItem('usuarioActual');
    if (usuarioGuardado) {
        mostrarOcultarAuditoria(usuarioGuardado);
        cargarStockDesdeBD();
    }
});

document.addEventListener('mousemove', function(e) {
    const imagePlatform = document.querySelector('.image-platform');
    const motoImg = document.querySelector('.moto-float');
    if (imagePlatform && motoImg && imagePlatform.matches(':hover')) {
        const rect = imagePlatform.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = (y - centerY) / 20;
        const rotateY = (centerX - x) / 20;
        motoImg.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-${Math.abs(rotateX) * 2}px)`;
    } else if (motoImg) {
        motoImg.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0px)';
    }
});

console.log('✅ Sistema Motos Toro cargado exitosamente (v2.0 - MySQL + Stock)');