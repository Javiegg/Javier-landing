-- ============================================
-- BASE DE DATOS: Motos TORO
-- ============================================

CREATE DATABASE IF NOT EXISTS motos_toro;
USE motos_toro;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'auditor', 'comprador') NOT NULL DEFAULT 'comprador',
    nombre_completo VARCHAR(100),
    email VARCHAR(100),
    activo TINYINT(1) DEFAULT 1,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla de motos con stock
CREATE TABLE IF NOT EXISTS motos (
    id VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    precio_2025 DECIMAL(10,2) NOT NULL,
    precio_2026 DECIMAL(10,2) NOT NULL,
    stock_2025 INT NOT NULL DEFAULT 5,
    stock_2026 INT NOT NULL DEFAULT 3,
    cilindrada VARCHAR(10),
    categoria VARCHAR(10),
    icono VARCHAR(10),
    activo TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

-- Tabla de auditoría
CREATE TABLE IF NOT EXISTS auditoria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    usuario_nombre VARCHAR(50),
    rol VARCHAR(20),
    accion ENUM('login', 'logout', 'consulta_stock', 'apartado') NOT NULL,
    fecha_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dispositivo VARCHAR(50),
    ip_address VARCHAR(45),
    detalles TEXT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Tabla de apartados
CREATE TABLE IF NOT EXISTS apartados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    moto_id VARCHAR(20),
    anio_modelo VARCHAR(4),
    plan VARCHAR(20),
    metodo_pago VARCHAR(30),
    monto_total DECIMAL(10,2),
    monto_apartado DECIMAL(10,2),
    cuotas INT,
    valor_cuota DECIMAL(10,2),
    fecha_apartado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado ENUM('pendiente', 'confirmado', 'cancelado') DEFAULT 'pendiente',
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    FOREIGN KEY (moto_id) REFERENCES motos(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================
-- INSERTAR DATOS INICIALES
-- ============================================

-- Usuarios (contraseña: 1234 para admin, 5678 para auditor, 0000 para comprador)
INSERT INTO usuarios (usuario, password, rol, nombre_completo, email) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Administrador Toro', 'admin@motorotormaracay.com'),
('auditor', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'auditor', 'Auditor Toro', 'auditor@motorotormaracay.com'),
('comprador', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'comprador', 'Cliente Demo', 'cliente@demo.com');

-- Motos con stock
INSERT INTO motos (id, nombre, precio_2025, precio_2026, stock_2025, stock_2026, cilindrada, categoria, icono) VALUES
('jaguar', 'Jaguar TR 150cc', 1190, 1309, 5, 3, '150cc', '150', '🔥'),
('rex', 'Rex TR 250cc', 2150, 2365, 5, 3, '250cc', '250', '🦖'),
('fox', 'Fox TR 180cc', 1840, 2024, 5, 3, '180cc', '180', '🦊'),
('leon', 'León TR 200cc', 1420, 1562, 5, 3, '200cc', '200', '🦁'),
('r3x', 'R3X 250cc', 2790, 3069, 5, 3, '250cc', '250', '🏁'),
('rex150', 'Rex TR 150cc', 1499, 1649, 5, 3, '150cc', '150', '🦖'),
('tank3', 'Tank III 180cc', 2500, 2750, 5, 3, '180cc', '180', '🛡️'),
('tankTr180', 'Tank TR 180cc', 1920, 2112, 5, 3, '180cc', '180', '🦾');