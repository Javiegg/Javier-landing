<?php
// ============================================
// BACKEND API - Motos TORO
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// Configuración de la base de datos
$host = 'localhost';
$dbname = 'motos_toro';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
    exit;
}

// Obtener la acción solicitada
$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    
    // ========== LOGIN ==========
    case 'login':
        $usuario = $_POST['usuario'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($usuario) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'Usuario y contraseña requeridos']);
            exit;
        }
        
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE usuario = ? AND activo = 1");
        $stmt->execute([$usuario]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            // Registrar en auditoría
            $dispositivo = strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false ? '📱 Móvil' : '💻 Escritorio';
            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            
            $stmt = $pdo->prepare("INSERT INTO auditoria (usuario_id, usuario_nombre, rol, accion, dispositivo, ip_address) VALUES (?, ?, ?, 'login', ?, ?)");
            $stmt->execute([$user['id'], $user['usuario'], $user['rol'], $dispositivo, $ip]);
            
            echo json_encode([
                'success' => true,
                'usuario' => $user['usuario'],
                'rol' => $user['rol'],
                'nombre_completo' => $user['nombre_completo'],
                'auditoria_id' => $pdo->lastInsertId()
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Usuario o contraseña incorrectos']);
        }
        break;
    
    // ========== LOGOUT (Registrar en auditoría) ==========
    case 'logout':
        $usuario_id = $_POST['usuario_id'] ?? 0;
        $usuario_nombre = $_POST['usuario'] ?? '';
        $rol = $_POST['rol'] ?? '';
        
        $dispositivo = strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false ? '📱 Móvil' : '💻 Escritorio';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        
        $stmt = $pdo->prepare("INSERT INTO auditoria (usuario_id, usuario_nombre, rol, accion, dispositivo, ip_address) VALUES (?, ?, ?, 'logout', ?, ?)");
        $stmt->execute([$usuario_id, $usuario_nombre, $rol, $dispositivo, $ip]);
        
        echo json_encode(['success' => true]);
        break;
    
    // ========== OBTENER STOCK DE MOTOS ==========
    case 'getStock':
        $stmt = $pdo->query("SELECT * FROM motos WHERE activo = 1 ORDER BY precio_2025 ASC");
        $motos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Registrar consulta en auditoría si hay usuario
        if (isset($_GET['usuario']) && isset($_GET['usuario_id'])) {
            $stmt = $pdo->prepare("INSERT INTO auditoria (usuario_id, usuario_nombre, rol, accion, detalles) VALUES (?, ?, ?, 'consulta_stock', 'Consulta de stock de motos')");
            $stmt->execute([$_GET['usuario_id'], $_GET['usuario'], $_GET['rol'] ?? 'comprador']);
        }
        
        echo json_encode(['success' => true, 'motos' => $motos]);
        break;
    
    // ========== OBTENER AUDITORÍA ==========
    case 'getAuditoria':
        $stmt = $pdo->query("SELECT * FROM auditoria ORDER BY fecha_hora DESC LIMIT 500");
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'logs' => $logs]);
        break;
    
    // ========== REGISTRAR APARTADO ==========
    case 'apartado':
        $usuario_id = $_POST['usuario_id'] ?? 0;
        $moto_id = $_POST['moto_id'] ?? '';
        $anio = $_POST['anio'] ?? '2025';
        $plan = $_POST['plan'] ?? 'basico';
        $metodo_pago = $_POST['metodo_pago'] ?? '';
        $monto_total = $_POST['monto_total'] ?? 0;
        $monto_apartado = $_POST['monto_apartado'] ?? 0;
        $cuotas = $_POST['cuotas'] ?? 12;
        $valor_cuota = $_POST['valor_cuota'] ?? 0;
        
        // Verificar stock
        $stockField = ($anio == '2025') ? 'stock_2025' : 'stock_2026';
        $stmt = $pdo->prepare("SELECT $stockField FROM motos WHERE id = ?");
        $stmt->execute([$moto_id]);
        $stock = $stmt->fetchColumn();
        
        if ($stock <= 0) {
            echo json_encode(['success' => false, 'message' => 'No hay stock disponible para este modelo']);
            exit;
        }
        
        // Registrar apartado
        $stmt = $pdo->prepare("INSERT INTO apartados (usuario_id, moto_id, anio_modelo, plan, metodo_pago, monto_total, monto_apartado, cuotas, valor_cuota) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$usuario_id, $moto_id, $anio, $plan, $metodo_pago, $monto_total, $monto_apartado, $cuotas, $valor_cuota]);
        
        // Reducir stock
        $stmt = $pdo->prepare("UPDATE motos SET $stockField = $stockField - 1 WHERE id = ?");
        $stmt->execute([$moto_id]);
        
        // Auditoría
        $stmt = $pdo->prepare("INSERT INTO auditoria (usuario_id, usuario_nombre, rol, accion, detalles) VALUES (?, ?, ?, 'apartado', ?)");
        $stmt->execute([$usuario_id, $_POST['usuario'] ?? '', $_POST['rol'] ?? 'comprador', "Apartado de $moto_id año $anio"]);
        
        echo json_encode(['success' => true, 'apartado_id' => $pdo->lastInsertId()]);
        break;
    
    default:
        echo json_encode(['error' => 'Acción no válida']);
}
?>