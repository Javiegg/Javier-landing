// ========== DATOS DE MOTOS ==========
const motos = {
    jaguar: { 
        nombre: "Jaguar 250cc", 
        precio: 940, 
        icono: "🔥",
        especificaciones: [
            "⚡ Motor: 4 tiempos, 250cc",
            "🔧 Potencia: 22 HP a 8500 RPM",
            "⚙️ Transmisión: 6 velocidades",
            "🚀 Velocidad máxima: 135 km/h",
            "⛽ Consumo: 30 km/litro",
            "🛑 Frenos: Disco (delantero y trasero)",
            "💨 Arranque: Eléctrico y patada"
        ]
    },
    rex: { 
        nombre: "Rex 200cc", 
        precio: 1100, 
        icono: "⚡",
        especificaciones: [
            "⚡ Motor: 4 tiempos, 200cc",
            "🔧 Potencia: 18 HP a 8000 RPM",
            "⚙️ Transmisión: 5 velocidades",
            "🚀 Velocidad máxima: 120 km/h",
            "⛽ Consumo: 35 km/litro",
            "🛑 Frenos: Disco (delantero) / Tambor (trasero)",
            "💨 Arranque: Eléctrico"
        ]
    },
    fox: { 
        nombre: "Toro Fox TR180", 
        precio: 850, 
        icono: "🦊",
        especificaciones: [
            "⚡ Motor: 4 tiempos, 180cc",
            "🔧 Potencia: 15 HP a 7500 RPM",
            "⚙️ Transmisión: 5 velocidades",
            "🚀 Velocidad máxima: 110 km/h",
            "⛽ Consumo: 38 km/litro",
            "🛑 Frenos: Disco (delantero) / Tambor (trasero)",
            "💨 Arranque: Eléctrico y patada",
            "🎨 Diseño deportivo y ágil"
        ]
    },
    leon: { 
        nombre: "Toro León TR200", 
        precio: 1050, 
        icono: "🦁",
        especificaciones: [
            "⚡ Motor: 4 tiempos, 200cc",
            "🔧 Potencia: 20 HP a 8200 RPM",
            "⚙️ Transmisión: 6 velocidades",
            "🚀 Velocidad máxima: 125 km/h",
            "⛽ Consumo: 32 km/litro",
            "🛑 Frenos: Doble disco",
            "💨 Arranque: Eléctrico",
            "👑 Edición especial León"
        ]
    },
    r3x: { 
        nombre: "Toro R3x 250", 
        precio: 1200, 
        icono: "🏁",
        especificaciones: [
            "⚡ Motor: 4 tiempos, 250cc",
            "🔧 Potencia: 25 HP a 9000 RPM",
            "⚙️ Transmisión: 6 velocidades",
            "🚀 Velocidad máxima: 145 km/h",
            "⛽ Consumo: 28 km/litro",
            "🛑 Frenos: Disco con ABS",
            "💨 Arranque: Eléctrico",
            "🏆 Versión deportiva de alto rendimiento"
        ]
    },
    rex150: { 
        nombre: "Toro Rex 150", 
        precio: 780, 
        icono: "⚡",
        especificaciones: [
            "⚡ Motor: 4 tiempos, 150cc",
            "🔧 Potencia: 12 HP a 7000 RPM",
            "⚙️ Transmisión: 5 velocidades",
            "🚀 Velocidad máxima: 100 km/h",
            "⛽ Consumo: 40 km/litro",
            "🛑 Frenos: Tambor (delantero y trasero)",
            "💨 Arranque: Eléctrico y patada",
            "💰 Ideal para principiantes"
        ]
    },
    tank3: { 
        nombre: "Toro Tank 3", 
        precio: 1350, 
        icono: "🐘",
        especificaciones: [
            "⚡ Motor: 4 tiempos, 300cc",
            "🔧 Potencia: 28 HP a 8500 RPM",
            "⚙️ Transmisión: 6 velocidades",
            "🚀 Velocidad máxima: 150 km/h",
            "⛽ Consumo: 25 km/litro",
            "🛑 Frenos: Doble disco con ABS",
            "💨 Arranque: Eléctrico",
            "🛡️ Diseño robusto tipo adventure"
        ]
    },
    tankTr180: { 
        nombre: "Toro Tank TR180", 
        precio: 980, 
        icono: "🐘",
        especificaciones: [
            "⚡ Motor: 4 tiempos, 180cc",
            "🔧 Potencia: 16 HP a 7800 RPM",
            "⚙️ Transmisión: 5 velocidades",
            "🚀 Velocidad máxima: 115 km/h",
            "⛽ Consumo: 35 km/litro",
            "🛑 Frenos: Disco (delantero) / Tambor (trasero)",
            "💨 Arranque: Eléctrico y patada",
            "🛡️ Versión económica del Tank"
        ]
    }
};

// ========== LOGIN ==========
const loginOverlay = document.getElementById('loginOverlay');
const mainContent = document.getElementById('mainContent');
const btnLogin = document.getElementById('btnLogin');
const btnLogout = document.getElementById('btnLogout');
const loginUser = document.getElementById('loginUser');
const loginPass = document.getElementById('loginPass');
const loginError = document.getElementById('loginError');

function validarLogin() {
    const user = loginUser.value.trim();
    const pass = loginPass.value;

    if (user === "admin" && pass === "1234") {
        loginError.style.display = 'none';
        loginOverlay.style.display = 'none';
        mainContent.classList.add('visible');
        localStorage.setItem('sesionActiva', 'true');
        mostrarNotificacion('¡Bienvenido ' + user + '!', 'exito');
        loginUser.value = '';
        loginPass.value = '';
    } else {
        loginError.style.display = 'block';
        loginPass.value = '';
        setTimeout(() => {
            loginError.style.display = 'none';
        }, 3000);
    }
}

function cerrarSesion() {
    mainContent.classList.remove('visible');
    loginOverlay.style.display = 'flex';
    localStorage.removeItem('sesionActiva');
    mostrarNotificacion('Sesión cerrada correctamente', 'info');
}

function mostrarNotificacion(mensaje, tipo) {
    const notificacion = document.createElement('div');
    notificacion.className = 'notificacion';
    notificacion.style.background = tipo === 'exito' ? '#4CAF50' : '#2196F3';
    notificacion.style.color = 'white';
    notificacion.innerHTML = `
        <i class="fas ${tipo === 'exito' ? 'fa-check-circle' : 'fa-info-circle'}"></i>
        <span>${mensaje}</span>
    `;
    document.body.appendChild(notificacion);
    setTimeout(() => {
        notificacion.style.animation = 'slideOutRight 0.5s ease forwards';
        setTimeout(() => notificacion.remove(), 500);
    }, 3000);
}

btnLogin.addEventListener('click', validarLogin);
btnLogout.addEventListener('click', cerrarSesion);
loginUser.addEventListener('keypress', (e) => { if (e.key === 'Enter') validarLogin(); });
loginPass.addEventListener('keypress', (e) => { if (e.key === 'Enter') validarLogin(); });

if (localStorage.getItem('sesionActiva') === 'true') {
    loginOverlay.style.display = 'none';
    mainContent.classList.add('visible');
}

// ========== FUNCIONES DEL MENÚ ==========
function mostrarPagina(pagina) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(`page-${pagina}`).classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ========== GENERAR TARJETAS DE MODELOS ==========
function generarModelosGrid() {
    const grid = document.getElementById('modelosGridPrincipal');
    if (!grid) return;
    
    const modelosLista = [
        { id: 'jaguar', nombre: 'Jaguar 250cc', precio: 940, icono: '🔥' },
        { id: 'rex', nombre: 'Rex 200cc', precio: 1100, icono: '⚡' },
        { id: 'fox', nombre: 'Toro Fox TR180', precio: 850, icono: '🦊' },
        { id: 'leon', nombre: 'Toro León TR200', precio: 1050, icono: '🦁' },
        { id: 'r3x', nombre: 'Toro R3x 250', precio: 1200, icono: '🏁' },
        { id: 'rex150', nombre: 'Toro Rex 150', precio: 780, icono: '⚡' },
        { id: 'tank3', nombre: 'Toro Tank 3', precio: 1350, icono: '🐘' },
        { id: 'tankTr180', nombre: 'Toro Tank TR180', precio: 980, icono: '🐘' }
    ];
    
    let html = '';
    modelosLista.forEach(moto => {
        html += `
            <div class="modelo-card-principal" onclick="verDetalleMoto('${moto.id}')">
                <div class="modelo-img-principal">
                    <i class="fas fa-motorcycle"></i> ${moto.icono}
                </div>
                <div class="modelo-info-principal">
                    <h3>${moto.nombre}</h3>
                    <div class="modelo-precio-principal">$${moto.precio} <span>USD</span></div>
                    <button class="btn-detalles">Ver detalles →</button>
                </div>
            </div>
        `;
    });
    
    grid.innerHTML = html;
}

// ========== VER DETALLE DE MOTO ==========
function verDetalleMoto(motoId) {
    const moto = motos[motoId];
    if (!moto) return;
    
    const imagenesModelos = {
        jaguar: "modelos/Jaguar.jpg",
        rex: "modelos/rextr250.jpg",
        fox: "modelos/fox.jpg",
        leon: "modelos/leon.jpg",
        r3x: "modelos/r3x.jpg",
        rex150: "modelos/rex150.jpg",
        tank3: "modelos/tank3.jpg",
        tankTr180: "modelos/tanktr180.jpg"
    };
    
    const imagenMoto = imagenesModelos[motoId] || "modelos/default.jpg";
    
    let detallePage = document.getElementById(`page-detalle-${motoId}`);
    
    if (!detallePage) {
        detallePage = document.createElement('div');
        detallePage.id = `page-detalle-${motoId}`;
        detallePage.className = 'page';
        
        let especHtml = '';
        moto.especificaciones.forEach(esp => {
            especHtml += `<li><i class="fas fa-check-circle" style="color:#8B0000"></i> ${esp}</li>`;
        });
        
        detallePage.innerHTML = `
    <button class="btn-volver" onclick="volverAModelos()">
        <i class="fas fa-arrow-left"></i> Volver a Modelos
    </button>
    
    <div class="specs-container">
        <div class="specs-content">
            <div class="specs-info">
                <h2 class="specs-title">Especificaciones Técnicas</h2>
                <ul class="specs-list">
                    ${moto.especificaciones.map(esp => {
                        // Extraer icono según el texto
                        let icono = 'fa-circle';
                        if (esp.includes('Motor')) icono = 'fa-bolt';
                        else if (esp.includes('Potencia')) icono = 'fa-wrench';
                        else if (esp.includes('Transmisión')) icono = 'fa-cog';
                        else if (esp.includes('Velocidad')) icono = 'fa-rocket';
                        else if (esp.includes('Consumo')) icono = 'fa-gas-pump';
                        else if (esp.includes('Frenos')) icono = 'fa-dot-circle';
                        else if (esp.includes('Arranque')) icono = 'fa-hand-sparkles';
                        else icono = 'fa-check-circle';
                        
                        return `<li><i class="fas ${icono}"></i> ${esp}</li>`;
                    }).join('')}
                </ul>
            </div>

            <div class="specs-image-wrapper">
                <div class="image-platform">
                    <img src="${imagenMoto}" alt="${moto.nombre}" class="moto-float">
                </div>
            </div>
        </div>
    </div>
    
    <button class="btn-apartar" onclick="irAFinanciamientoConMoto('${motoId}')">
        <i class="fas fa-hand-holding-usd"></i> APARTAR ESTA MOTO
    </button>
`;
        
        document.querySelector('.page-container').appendChild(detallePage);
    }
    
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    detallePage.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function volverAModelos() {
    mostrarPagina('modelos');
}

// ========== FINANCIAMIENTO - VARIABLES GLOBALES ==========
let planSeleccionado = null;
let metodoPagoSeleccionado = null;
let montoApartadoPlan = null;
let cuotasPlan = null;
let tasaInteresPlan = null;
let motoSeleccionadaParaFinanciamiento = null;

// Planes de financiamiento
const planesFinanciamiento = {
    basico: {
        nombre: "Plan Básico",
        apartado: 150,
        cuotas: 12,
        interes: 0,
        beneficios: ["Sin intereses", "Aprobación inmediata"]
    },
    premium: {
        nombre: "Plan Premium",
        apartado: 300,
        cuotas: 24,
        interes: 5,
        beneficios: ["Tasa preferencial", "Beneficios exclusivos", "Mantenimiento gratis 1 año"]
    }
};

// Métodos de pago
const metodosPago = {
    transferencia: { nombre: "Transferencia Bancaria", icono: "🏦", tiempo: "24-48 horas" },
    movil: { nombre: "Pago Móvil", icono: "📱", tiempo: "Inmediato" },
    efectivo: { nombre: "Efectivo", icono: "💵", tiempo: "Inmediato" },
    tarjeta: { nombre: "Tarjeta de Crédito/Débito", icono: "💳", tiempo: "Inmediato" }
};

// Función para ir a financiamiento con una moto seleccionada
function irAFinanciamientoConMoto(motoId) {
    motoSeleccionadaParaFinanciamiento = motos[motoId];
    mostrarPagina('financiamiento');
    mostrarNotificacion(`Moto seleccionada: ${motoSeleccionadaParaFinanciamiento.nombre} - Precio: $${motoSeleccionadaParaFinanciamiento.precio}`, 'exito');
}

// Función para seleccionar plan
function seleccionarPlan(plan) {
    planSeleccionado = plan;
    const planData = planesFinanciamiento[plan];
    montoApartadoPlan = planData.apartado;
    cuotasPlan = planData.cuotas;
    tasaInteresPlan = planData.interes;
    
    document.querySelectorAll('.financing-card').forEach(card => {
        card.classList.remove('seleccionado');
    });
    
    const cards = document.querySelectorAll('.financing-card');
    if (plan === 'basico') cards[0].classList.add('seleccionado');
    if (plan === 'premium') cards[1].classList.add('seleccionado');
    
    mostrarNotificacion(`Has seleccionado el ${planData.nombre}`, 'exito');
    
    if (metodoPagoSeleccionado) {
        mostrarResumenFinanciamiento();
    }
}

// Función para seleccionar método de pago
function seleccionarMetodoPago(metodo) {
    metodoPagoSeleccionado = metodo;
    
    document.querySelectorAll('.payment-methods span').forEach(span => {
        span.classList.remove('seleccionado');
    });
    
    const metodos = document.querySelectorAll('.payment-methods span');
    const metodoMap = { transferencia: 0, movil: 1, efectivo: 2, tarjeta: 3 };
    if (metodoMap[metodo] !== undefined) {
        metodos[metodoMap[metodo]].classList.add('seleccionado');
    }
    
    const metodoData = metodosPago[metodo];
    mostrarNotificacion(`Has seleccionado ${metodoData.nombre}`, 'exito');
    
    if (planSeleccionado) {
        mostrarResumenFinanciamiento();
    }
}

// Función para mostrar resumen del financiamiento
function mostrarResumenFinanciamiento() {
    if (!motoSeleccionadaParaFinanciamiento) {
        mostrarNotificacion('Por favor, selecciona una moto primero desde la sección de Modelos', 'info');
        return;
    }
    
    const planData = planesFinanciamiento[planSeleccionado];
    const metodoData = metodosPago[metodoPagoSeleccionado];
    
    const montoApartado = planData.apartado;
    const cuotasMensuales = Math.ceil((motoSeleccionadaParaFinanciamiento.precio - montoApartado) / planData.cuotas);
    const totalFinanciado = motoSeleccionadaParaFinanciamiento.precio;
    
    const resumenHTML = `
        <div class="resumen-contenido">
            <div class="resumen-item">
                <span>🏍️ Moto seleccionada:</span>
                <strong>${motoSeleccionadaParaFinanciamiento.nombre}</strong>
            </div>
            <div class="resumen-item">
                <span>💰 Precio total:</span>
                <strong>$${motoSeleccionadaParaFinanciamiento.precio} USD</strong>
            </div>
            <div class="resumen-item">
                <span>📋 Plan seleccionado:</span>
                <strong>${planData.nombre}</strong>
            </div>
            <div class="resumen-item">
                <span>💵 Monto de apartado:</span>
                <strong>$${planData.apartado} USD</strong>
            </div>
            <div class="resumen-item">
                <span>📅 Número de cuotas:</span>
                <strong>${planData.cuotas} cuotas</strong>
            </div>
            <div class="resumen-item">
                <span>💰 Valor de cada cuota:</span>
                <strong>$${cuotasMensuales} USD</strong>
            </div>
            <div class="resumen-item">
                <span>💳 Método de pago:</span>
                <strong>${metodoData.nombre} ${metodoData.icono}</strong>
            </div>
            <div class="resumen-item">
                <span>⏱️ Tiempo de procesamiento:</span>
                <strong>${metodoData.tiempo}</strong>
            </div>
            ${planData.interes > 0 ? `
            <div class="resumen-item">
                <span>📈 Interés aplicado:</span>
                <strong>${planData.interes}%</strong>
            </div>
            ` : ''}
            <div class="resumen-item total">
                <span>🎯 Total a pagar:</span>
                <strong>$${motoSeleccionadaParaFinanciamiento.precio} USD</strong>
            </div>
        </div>
    `;
    
    const resumenDiv = document.getElementById('resumen-contenido');
    if (resumenDiv) {
        resumenDiv.innerHTML = resumenHTML;
    }
    
    document.getElementById('financiamiento-resumen').style.display = 'block';
}

// Función para confirmar financiamiento y generar factura
function confirmarFinanciamiento() {
    if (!motoSeleccionadaParaFinanciamiento) {
        mostrarNotificacion('Error: No hay una moto seleccionada', 'error');
        return;
    }
    
    const planData = planesFinanciamiento[planSeleccionado];
    const metodoData = metodosPago[metodoPagoSeleccionado];
    
    const fecha = new Date();
    const fechaApartado = fecha.toLocaleDateString();
    fecha.setDate(fecha.getDate() + 30);
    const fechaLimite = fecha.toLocaleDateString();
    fecha.setDate(fecha.getDate() - 30);
    
    const numeroFactura = 'FT-' + fecha.getFullYear() + '-' + Math.floor(Math.random() * 10000);
    const montoApartado = planData.apartado;
    const cuotasMensuales = Math.ceil((motoSeleccionadaParaFinanciamiento.precio - montoApartado) / planData.cuotas);
    const saldoPendiente = motoSeleccionadaParaFinanciamiento.precio - montoApartado;
    
    const facturaHTML = `
        <div class="factura-linea">
            <span>📄 N° Factura:</span>
            <strong>${numeroFactura}</strong>
        </div>
        <div class="factura-linea">
            <span>📅 Fecha:</span>
            <strong>${fechaApartado}</strong>
        </div>
        <div class="factura-linea">
            <span>🏍️ Modelo:</span>
            <strong>${motoSeleccionadaParaFinanciamiento.nombre}</strong>
        </div>
        <div class="factura-linea">
            <span>💰 Precio total:</span>
            <strong>$${motoSeleccionadaParaFinanciamiento.precio} USD</strong>
        </div>
        <div class="factura-linea">
            <span>📋 Plan:</span>
            <strong>${planData.nombre}</strong>
        </div>
        <div class="factura-linea">
            <span>💵 Monto apartado:</span>
            <strong>$${montoApartado} USD</strong>
        </div>
        <div class="factura-linea">
            <span>📊 Saldo pendiente:</span>
            <strong>$${saldoPendiente} USD</strong>
        </div>
        <div class="factura-linea">
            <span>📅 Cuotas:</span>
            <strong>${planData.cuotas} cuotas de $${cuotasMensuales} USD</strong>
        </div>
        <div class="factura-linea">
            <span>💳 Método de pago:</span>
            <strong>${metodoData.nombre} ${metodoData.icono}</strong>
        </div>
        <div class="factura-linea">
            <span>⏱️ Tiempo de procesamiento:</span>
            <strong>${metodoData.tiempo}</strong>
        </div>
        <div class="factura-linea">
            <span>⏰ Fecha límite de pago:</span>
            <strong>${fechaLimite}</strong>
        </div>
        ${planData.interes > 0 ? `
        <div class="factura-linea">
            <span>📈 Interés:</span>
            <strong>${planData.interes}%</strong>
        </div>
        ` : ''}
        <div class="factura-linea total">
            <span>🎉 Estado:</span>
            <strong style="color:#4CAF50">¡APARTADO EXITOSO! ✅</strong>
        </div>
    `;
    
    document.getElementById('factura-contenido').innerHTML = facturaHTML;
    
    document.getElementById('financiamiento-resumen').style.display = 'none';
    document.getElementById('factura-final').style.display = 'block';
    
    mostrarNotificacion('¡Financiamiento aprobado! Factura generada', 'exito');
    
    document.getElementById('factura-final').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Función para cancelar financiamiento
function cancelarFinanciamiento() {
    planSeleccionado = null;
    metodoPagoSeleccionado = null;
    document.getElementById('financiamiento-resumen').style.display = 'none';
    
    document.querySelectorAll('.financing-card').forEach(card => {
        card.classList.remove('seleccionado');
    });
    document.querySelectorAll('.payment-methods span').forEach(span => {
        span.classList.remove('seleccionado');
    });
    
    mostrarNotificacion('Financiamiento cancelado', 'info');
}

// Función para imprimir factura
function imprimirFactura() {
    const facturaContent = document.getElementById('factura-final').innerHTML;
    const ventana = window.open('', '_blank');
    ventana.document.write(`
        <html>
        <head>
            <title>Factura Motos Toro</title>
            <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;700;800&display=swap" rel="stylesheet">
            <style>
                body { font-family: 'Montserrat', sans-serif; padding: 30px; }
                .factura-card { max-width: 500px; margin: 0 auto; border: 2px solid #8B0000; border-radius: 20px; padding: 30px; }
                .factura-header { text-align: center; border-bottom: 2px dashed #ddd; padding-bottom: 20px; margin-bottom: 20px; }
                .factura-header h2 { color: #8B0000; }
                .factura-linea { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }
                .factura-linea.total { font-weight: bold; color: #8B0000; border-top: 2px solid #8B0000; border-bottom: none; }
                .factura-footer { text-align: center; margin-top: 20px; padding-top: 20px; border-top: 2px dashed #ddd; }
                @media print {
                    button { display: none; }
                }
            </style>
        </head>
        <body>
            ${facturaContent}
            <div class="factura-footer">
                <p>¡Gracias por confiar en Motos Toro Maracay!</p>
                <p>© 2024 - Todos los derechos reservados</p>
            </div>
        </body>
        </html>
    `);
    ventana.print();
}

// Función para regresar al menú principal
function regresarAlMenu() {
    // Resetear todas las variables
    planSeleccionado = null;
    metodoPagoSeleccionado = null;
    motoSeleccionadaParaFinanciamiento = null;
    
    // Ocultar factura y resumen
    document.getElementById('factura-final').style.display = 'none';
    document.getElementById('financiamiento-resumen').style.display = 'none';
    
    // Limpiar selecciones visuales
    document.querySelectorAll('.financing-card').forEach(card => {
        card.classList.remove('seleccionado');
    });
    document.querySelectorAll('.payment-methods span').forEach(span => {
        span.classList.remove('seleccionado');
    });
    
    // Ir al inicio
    mostrarPagina('inicio');
    mostrarNotificacion('Has regresado al menú principal', 'info');
}

// ========== EFECTO 3D EN IMÁGENES DE MOTOS CON PISO ==========
function iniciarEfecto3D() {
    const imagePlatform = document.querySelector('.image-platform');
    const motoImg = document.querySelector('.moto-float');
    const motoShadow = document.querySelector('.moto-shadow');
    const floorLight = document.querySelector('.floor-light');
    
    if (imagePlatform && motoImg) {
        imagePlatform.addEventListener('mousemove', (e) => {
            const rect = imagePlatform.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            let rotateX = (y - centerY) / 20;
            let rotateY = (centerX - x) / 20;
            let translateZ = Math.abs(rotateX) * 2 + Math.abs(rotateY) * 2;
            
            // Rotación de la moto
            motoImg.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-${translateZ}px)`;
            
            // Sombra que se mueve con la moto
            if (motoShadow) {
                let shadowX = (centerX - x) / 30;
                let shadowY = (y - centerY) / 30;
                motoShadow.style.transform = `translateX(${shadowX}px) translateY(${shadowY}px)`;
                motoShadow.style.filter = `blur(${4 + Math.abs(rotateX) * 2}px)`;
            }
            
            // Luz del piso que se mueve
            if (floorLight) {
                let lightX = (centerX - x) / 20;
                floorLight.style.transform = `translateX(${lightX}px)`;
                floorLight.style.opacity = 0.5 + Math.abs(rotateX) * 0.05;
            }
        });
        
        imagePlatform.addEventListener('mouseleave', () => {
            // Resetear moto
            motoImg.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0px)';
            
            // Resetear sombra
            if (motoShadow) {
                motoShadow.style.transform = 'translateX(0px) translateY(0px)';
                motoShadow.style.filter = 'blur(6px)';
            }
            
            // Resetear luz
            if (floorLight) {
                floorLight.style.transform = 'translateX(0px)';
                floorLight.style.opacity = 0.3;
            }
        });
    }
}

// ========== INICIALIZAR ==========
generarModelosGrid();