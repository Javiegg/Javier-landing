// ========== LOADER ==========
window.addEventListener('load', function() {
    setTimeout(() => {
        document.getElementById('pageLoader').classList.add('hidden');
    }, 1000);
});

// ========== SISTEMA DE AUDITORÍA Y ROLES ==========
const usuariosAutorizados = ['admin', 'auditor'];
const auditoriaLogs = JSON.parse(localStorage.getItem('auditoriaLogs') || '[]');

function obtenerRol(usuario) {
    if (usuario === 'admin') return 'Administrador';
    if (usuario === 'auditor') return 'Auditor';
    return 'Comprador';
}

function registrarAuditoria(usuario, accion) {
    const ahora = new Date();
    const registro = {
        id: auditoriaLogs.length + 1,
        usuario: usuario,
        rol: obtenerRol(usuario),
        fecha: ahora.toLocaleDateString('es-ES'),
        hora: ahora.toLocaleTimeString('es-ES'),
        fechaHora: ahora.toISOString(),
        dispositivo: navigator.userAgent.includes('Mobile') ? '📱 Móvil' : '💻 Escritorio',
        accion: accion
    };
    auditoriaLogs.push(registro);
    localStorage.setItem('auditoriaLogs', JSON.stringify(auditoriaLogs));
}

function mostrarOcultarAuditoria(usuario) {
    const navAuditoria = document.querySelector('.nav-auditoria');
    if (navAuditoria) {
        if (usuariosAutorizados.includes(usuario)) {
            navAuditoria.style.display = 'block';
        } else {
            navAuditoria.style.display = 'none';
        }
    }
}

function cargarTablaAuditoria() {
    const tbody = document.getElementById('auditoriaTablaBody');
    if (!tbody) return;
    
    const logsOrdenados = [...auditoriaLogs].reverse();
    
    if (logsOrdenados.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="sin-datos"><i class="fas fa-inbox"></i>No hay registros de auditoría</td></tr>`;
    } else {
        tbody.innerHTML = logsOrdenados.map(log => `
            <tr>
                <td>#${log.id}</td>
                <td><strong>${log.usuario}</strong></td>
                <td><span class="auditoria-badge-rol ${log.rol.toLowerCase()}">${log.rol}</span></td>
                <td>${log.fecha} - ${log.hora}</td>
                <td>${log.dispositivo}</td>
                <td><span class="auditoria-badge-accion ${log.accion}">${log.accion === 'login' ? '✅ Ingreso' : '🚪 Salida'}</span></td>
            </tr>
        `).join('');
    }
    
    actualizarEstadisticas();
}

function actualizarEstadisticas() {
    const totalUsuariosEl = document.getElementById('totalUsuarios');
    const totalAccesosEl = document.getElementById('totalAccesos');
    const accesosHoyEl = document.getElementById('accesosHoy');
    
    if (!totalUsuariosEl) return;
    
    const usuariosUnicos = [...new Set(auditoriaLogs.map(log => log.usuario))];
    totalUsuariosEl.textContent = usuariosUnicos.length;
    totalAccesosEl.textContent = auditoriaLogs.length;
    
    const hoy = new Date().toLocaleDateString('es-ES');
    const accesosHoy = auditoriaLogs.filter(log => log.fecha === hoy);
    accesosHoyEl.textContent = accesosHoy.length;
}

function filtrarAuditoria() {
    const filtroUsuario = document.getElementById('filtroUsuario').value.toLowerCase();
    const filtroFecha = document.getElementById('filtroFecha').value;
    const tbody = document.getElementById('auditoriaTablaBody');
    
    let logsFiltrados = [...auditoriaLogs].reverse();
    
    if (filtroUsuario) {
        logsFiltrados = logsFiltrados.filter(log => log.usuario.toLowerCase().includes(filtroUsuario));
    }
    
    if (filtroFecha) {
        const fechaBuscada = new Date(filtroFecha + 'T00:00:00').toLocaleDateString('es-ES');
        logsFiltrados = logsFiltrados.filter(log => log.fecha === fechaBuscada);
    }
    
    if (logsFiltrados.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="sin-datos"><i class="fas fa-search"></i>No se encontraron registros</td></tr>`;
    } else {
        tbody.innerHTML = logsFiltrados.map(log => `
            <tr>
                <td>#${log.id}</td>
                <td><strong>${log.usuario}</strong></td>
                <td><span class="auditoria-badge-rol ${log.rol.toLowerCase()}">${log.rol}</span></td>
                <td>${log.fecha} - ${log.hora}</td>
                <td>${log.dispositivo}</td>
                <td><span class="auditoria-badge-accion ${log.accion}">${log.accion === 'login' ? '✅ Ingreso' : '🚪 Salida'}</span></td>
            </tr>
        `).join('');
    }
}

function limpiarFiltros() {
    document.getElementById('filtroUsuario').value = '';
    document.getElementById('filtroFecha').value = '';
    cargarTablaAuditoria();
}

function exportarAuditoria() {
    let csv = 'ID,Usuario,Rol,Fecha,Hora,Dispositivo,Acción\n';
    auditoriaLogs.forEach(log => {
        csv += `${log.id},"${log.usuario}","${log.rol}","${log.fecha}","${log.hora}","${log.dispositivo}","${log.accion}"\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `auditoria_motos_toro_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
}

// ========== DATOS DE MOTOS ==========
const motos = {
    jaguar: { nombre: "Jaguar TR 150cc", precio: 1190, icono: "🔥", cilindrada: "150cc", categoria: "150", especificaciones: ["⚡ Motor: Monocilíndrico 150cc", "🔧 Tanque: 14 Litros", "⚙️ Transmisión: 5 velocidades", "🚀 Velocidad máxima: 100 km/h", "⛽ Parrilla: Trasera reforzada de fábrica", "🛑 Frenos: Disco (delantero) / Tambor (trasero)", "💨 Uso: Trabajo pesado / Mensajería"] },
    rex: { nombre: "Rex TR 250cc", precio: 2150, icono: "🦖", cilindrada: "250cc", categoria: "250", especificaciones: ["⚡ Motor: 250cc Loncin (Cadena de tiempo)", "🔧 Transmisión: 6 velocidades", "⚙️ Suspensión: Monoshock trasero y barras reforzadas", "🚀 Iluminación: Full LED (Faro de profundidad)", "⛽ Tablero: Digital completo", "🛑 Frenos: Disco (delantero) / Tambor (trasero)", "💨 Extras: Asiento ergonómico de dos niveles"] },
    fox: { nombre: "Fox TR 180cc", precio: 1840, icono: "🦊", cilindrada: "180cc", categoria: "180", especificaciones: ["⚡ Motor: 4 tiempos, monocilíndrico 180cc", "🔧 Potencia: 14.5 HP", "⚙️ Transmisión: 5 velocidades", "🚀 Velocidad máxima: 115 km/h", "⛽ Consumo: 32 km/litro", "🛑 Frenos: Disco (delantero) / Tambor (trasero)", "💨 Arranque: Eléctrico y patada"] },
    leon: { nombre: "León TR 200cc", precio: 1420, icono: "🦁", cilindrada: "200cc", categoria: "200", especificaciones: ["⚡ Motor: OHC con balanceador (vibración reducida)", "🔧 Capacidad de Tanque: 17 Litros", "⚙️ Transmisión: 5 velocidades", "🚀 Luces: Full LED (Faro, stop y cruces)", "⛽ Tablero: Análogo con indicador de marcha", "🛑 Frenos: Disco (delantero) / Tambor (trasero)", "💨 Cauchos: 3.0-18 (D) / 110-90-16 (T)"] },
    r3x: { nombre: "R3X 250cc", precio: 2790, icono: "🏁", cilindrada: "250cc", categoria: "250", especificaciones: ["⚡ Motor: Cadenillo de alto rendimiento", "🔧 Estilo: Deportiva / Touring", "⚙️ Transmisión: 6 velocidades", "🚀 Velocidad máxima: 135 km/h", "⛽ Seguridad: Frenos de disco en ambas ruedas", "🛑 Suspensión: Barras invertidas (delanteras)", "💨 Arranque: Eléctrico"] },
    rex150: { nombre: "Rex TR 150cc", precio: 1499, icono: "🦖", cilindrada: "150cc", categoria: "150", especificaciones: ["⚡ Motor: 150cc Enduro / Doble Propósito", "🔧 Accesorios: Incluye casco V2 original", "⚙️ Transmisión: 5 velocidades", "🚀 Velocidad máxima: 105 km/h", "⛽ Tanque: Reforzado para uso rudo", "🛑 Frenos: Disco (delantero)", "💨 Arranque: Eléctrico y patada"] },
    tank3: { nombre: "Tank III 180cc", precio: 2500, icono: "🛡️", cilindrada: "180cc", categoria: "180", especificaciones: ["⚡ Motor: 180cc Automático (Scooter)", "🔧 Diseño: Maxiscooter de lujo", "⚙️ Transmisión: Automática CVT", "🚀 Velocidad máxima: 110 km/h", "⛽ Comodidad: Asiento doble nivel ergonómico", "🛑 Frenos: Disco en ambas ruedas", "💨 Extras: Luces LED y tablero digital"] },
    tankTr180: { nombre: "Tank TR 180cc", precio: 1920, icono: "🦾", cilindrada: "180cc", categoria: "180", especificaciones: ["⚡ Motor: 180cc Automática", "🔧 Uso: Urbano / Diario", "⚙️ Transmisión: Automática", "🚀 Velocidad máxima: 105 km/h", "⛽ Capacidad: Maletero bajo el asiento", "🛑 Frenos: Disco (delantero)", "💨 Sistema: Alarma de fábrica"] }
};

// ========== TOGGLE PASSWORD ==========
document.getElementById('togglePassword')?.addEventListener('click', function() {
    const passwordInput = document.getElementById('loginPass');
    const icon = this.querySelector('i');
    if (passwordInput.type === 'password') { passwordInput.type = 'text'; icon.classList.remove('fa-eye'); icon.classList.add('fa-eye-slash'); }
    else { passwordInput.type = 'password'; icon.classList.remove('fa-eye-slash'); icon.classList.add('fa-eye'); }
});

// ========== LOGIN ==========
const loginOverlay = document.getElementById('loginOverlay');
const mainContent = document.getElementById('mainContent');
const btnLogin = document.getElementById('btnLogin');
const btnLogout = document.getElementById('btnLogout');
const loginUser = document.getElementById('loginUser');
const loginPass = document.getElementById('loginPass');
const loginError = document.getElementById('loginError');
const rememberMe = document.getElementById('rememberMe');

if (localStorage.getItem('rememberedUser')) { loginUser.value = localStorage.getItem('rememberedUser'); rememberMe.checked = true; }

function validarLogin() {
    const user = loginUser.value.trim();
    const pass = loginPass.value;
    
    let credencialesValidas = false;
    if (user === "admin" && pass === "1234") credencialesValidas = true;
    else if (user === "auditor" && pass === "5678") credencialesValidas = true;
    else if (user === "comprador" && pass === "0000") credencialesValidas = true;
    
    if (credencialesValidas) {
        loginError.style.display = 'none';
        loginOverlay.style.display = 'none';
        mainContent.classList.add('visible');
        
        if (rememberMe.checked) localStorage.setItem('rememberedUser', user);
        else localStorage.removeItem('rememberedUser');
        
        localStorage.setItem('sesionActiva', 'true');
        localStorage.setItem('usuarioActual', user);
        localStorage.setItem('rolActual', obtenerRol(user));
        document.getElementById('userName').textContent = obtenerRol(user);
        
        registrarAuditoria(user, 'login');
        mostrarOcultarAuditoria(user);
        
        mostrarNotificacion('¡Bienvenido ' + obtenerRol(user) + '!', 'exito');
        loginUser.value = '';
        loginPass.value = '';
    } else {
        loginError.style.display = 'block';
        loginPass.value = '';
        loginError.style.animation = 'none';
        setTimeout(() => loginError.style.animation = 'shake 0.5s ease', 10);
        setTimeout(() => loginError.style.display = 'none', 3000);
    }
}

function cerrarSesion() {
    const usuarioActual = localStorage.getItem('usuarioActual') || 'Usuario';
    registrarAuditoria(usuarioActual, 'logout');
    mainContent.classList.remove('visible');
    loginOverlay.style.display = 'flex';
    localStorage.removeItem('sesionActiva');
    localStorage.removeItem('usuarioActual');
    localStorage.removeItem('rolActual');
    mostrarNotificacion('Sesión cerrada correctamente', 'info');
}

function mostrarNotificacion(mensaje, tipo) {
    const notificacion = document.createElement('div'); notificacion.className = 'notificacion';
    const colores = { exito: '#10b981', info: '#3b82f6', error: '#ef4444', warning: '#f59e0b' };
    notificacion.style.background = colores[tipo] || colores.info; notificacion.style.color = 'white';
    const iconos = { exito: 'fa-check-circle', info: 'fa-info-circle', error: 'fa-exclamation-triangle', warning: 'fa-exclamation-circle' };
    notificacion.innerHTML = `<i class="fas ${iconos[tipo]}"></i><span>${mensaje}</span>`;
    document.body.appendChild(notificacion);
    setTimeout(() => { notificacion.style.animation = 'slideOutRight 0.5s ease forwards'; setTimeout(() => notificacion.remove(), 500); }, 3000);
}

btnLogin.addEventListener('click', validarLogin);
btnLogout.addEventListener('click', cerrarSesion);
loginUser.addEventListener('keypress', (e) => { if (e.key === 'Enter') validarLogin(); });
loginPass.addEventListener('keypress', (e) => { if (e.key === 'Enter') validarLogin(); });

if (localStorage.getItem('sesionActiva') === 'true') {
    loginOverlay.style.display = 'none';
    mainContent.classList.add('visible');
    const usuarioGuardado = localStorage.getItem('usuarioActual');
    if (usuarioGuardado) {
        document.getElementById('userName').textContent = obtenerRol(usuarioGuardado);
        mostrarOcultarAuditoria(usuarioGuardado);
    }
}

// ========== FUNCIONES DEL MENÚ ==========
function mostrarPagina(pagina) {
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.getElementById(`page-${pagina}`).classList.add('active');
    document.querySelectorAll('.nav-item').forEach(item => { item.classList.remove('active'); if (item.dataset.page === pagina) item.classList.add('active'); });
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    if (pagina === 'auditoria') {
        cargarTablaAuditoria();
    }
}

// ========== FILTROS DE MODELOS ==========
let filtroActual = 'all';
document.querySelectorAll('.filter-btn').forEach(btn => { btn.addEventListener('click', function() { document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active')); this.classList.add('active'); filtroActual = this.dataset.filter; generarModelosGrid(); }); });

// ========== GENERAR TARJETAS DE MODELOS ==========
function generarModelosGrid() {
    const grid = document.getElementById('modelosGridPrincipal'); if (!grid) return;
    const modelosLista = [
        { id: 'jaguar', nombre: 'Jaguar TR 150cc', precio: 1190, icono: '🔥', categoria: '150', cilindrada: '150cc' },
        { id: 'rex', nombre: 'Rex TR 250cc', precio: 2150, icono: '🦖', categoria: '250', cilindrada: '250cc' },
        { id: 'fox', nombre: 'Fox TR 180cc', precio: 1840, icono: '🦊', categoria: '180', cilindrada: '180cc' },
        { id: 'leon', nombre: 'León TR 200cc', precio: 1420, icono: '🦁', categoria: '200', cilindrada: '200cc' },
        { id: 'r3x', nombre: 'R3X 250cc', precio: 2790, icono: '🏁', categoria: '250', cilindrada: '250cc' },
        { id: 'rex150', nombre: 'Rex TR 150cc', precio: 1499, icono: '🦖', categoria: '150', cilindrada: '150cc' },
        { id: 'tank3', nombre: 'Tank III 180cc', precio: 2500, icono: '🛡️', categoria: '180', cilindrada: '180cc' },
        { id: 'tankTr180', nombre: 'Tank TR 180cc', precio: 1920, icono: '🦾', categoria: '180', cilindrada: '180cc' }
    ];
    const modelosFiltrados = filtroActual === 'all' ? modelosLista : modelosLista.filter(m => m.categoria === filtroActual);
    const imagenesModelos = { jaguar: "modelos/Jaguar.jpg", rex: "modelos/rextr250.jpg", fox: "modelos/fox.jpg", leon: "modelos/leon.jpg", r3x: "modelos/r3x.jpg", rex150: "modelos/rex150.jpg", tank3: "modelos/tank3.jpg", tankTr180: "modelos/tanktr180.jpg" };
    let html = '';
    modelosFiltrados.forEach(moto => {
        const financiamiento = Math.ceil(moto.precio / 12); const imagenMoto = imagenesModelos[moto.id] || `modelos/${moto.id}.jpg`;
        html += `<div class="modelo-card-principal" onclick="verDetalleMoto('${moto.id}')">
            <div class="modelo-img-principal">
                <img src="${imagenMoto}" alt="${moto.nombre}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <i class="fas fa-motorcycle" style="display: none; font-size: 50px; color: #8B0000;"></i>
                <span class="modelo-badge">${moto.icono} ${moto.cilindrada}</span>
            </div>
            <div class="modelo-info-principal">
                <div class="modelo-marca">MOTOS TORO</div>
                <h3>${moto.nombre}</h3>
                <div class="modelo-especificaciones-mini">
                    <span class="espec-item"><i class="fas fa-tachometer-alt"></i> ${moto.cilindrada}</span>
                    <span class="espec-item"><i class="fas fa-gas-pump"></i> 30+ km/l</span>
                </div>
                <div class="modelo-precio-principal">
                    <div class="precio-valor">$${moto.precio} <small>USD</small></div>
                    <div class="precio-financiamiento">Desde $${financiamiento}/mes</div>
                </div>
                <button class="btn-detalles" onclick="event.stopPropagation(); verDetalleMoto('${moto.id}')">Ver detalles <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>`;
    });
    grid.innerHTML = html || '<p style="text-align: center; grid-column: 1/-1;">No hay modelos en esta categoría</p>';
}

// ========== VER DETALLE DE MOTO ==========
function verDetalleMoto(motoId) {
    const moto = motos[motoId]; if (!moto) return;
    const imagenesModelos = { jaguar: "modelos/Jaguar.jpg", rex: "modelos/rextr250.jpg", fox: "modelos/fox.jpg", leon: "modelos/leon.jpg", r3x: "modelos/r3x.jpg", rex150: "modelos/rex150.jpg", tank3: "modelos/tank3.jpg", tankTr180: "modelos/tanktr180.jpg" };
    const imagenMoto = imagenesModelos[motoId] || "modelos/default.jpg";
    let detallePage = document.getElementById(`page-detalle-${motoId}`);
    if (!detallePage) {
        detallePage = document.createElement('div'); detallePage.id = `page-detalle-${motoId}`; detallePage.className = 'page';
        detallePage.innerHTML = `<button class="btn-volver" onclick="volverAModelos()"><i class="fas fa-arrow-left"></i> Volver a Modelos</button>
            <div class="specs-container"><div class="specs-content">
                <div class="specs-info"><h2 class="specs-title">Especificaciones Técnicas</h2><ul class="specs-list">${moto.especificaciones.map(esp => { let icono = 'fa-circle'; if (esp.includes('Motor')) icono = 'fa-bolt'; else if (esp.includes('Potencia')||esp.includes('Tanque')||esp.includes('Capacidad')||esp.includes('Accesorios')||esp.includes('Diseño')||esp.includes('Estilo')) icono = 'fa-wrench'; else if (esp.includes('Transmisión')) icono = 'fa-cog'; else if (esp.includes('Velocidad')||esp.includes('Luces')||esp.includes('Iluminación')) icono = 'fa-rocket'; else if (esp.includes('Consumo')||esp.includes('Tablero')) icono = 'fa-gas-pump'; else if (esp.includes('Frenos')||esp.includes('Seguridad')) icono = 'fa-dot-circle'; else if (esp.includes('Arranque')||esp.includes('Suspensión')||esp.includes('Extras')||esp.includes('Sistema')||esp.includes('Cauchos')||esp.includes('Comodidad')||esp.includes('Uso')||esp.includes('Parrilla')) icono = 'fa-hand-sparkles'; return `<li><i class="fas ${icono}"></i> ${esp}</li>`; }).join('')}</ul></div>
                <div class="specs-image-wrapper"><div class="image-platform"><img src="${imagenMoto}" alt="${moto.nombre}" class="moto-float" onerror="this.src='modelos/default.jpg'"></div></div>
            </div></div>
            <button class="btn-apartar" onclick="irAFinanciamientoConMoto('${motoId}')"><i class="fas fa-hand-holding-usd"></i> APARTAR ESTA MOTO</button>`;
        document.querySelector('.page-container').appendChild(detallePage);
    }
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active')); detallePage.classList.add('active'); window.scrollTo({ top: 0, behavior: 'smooth' });
}
function volverAModelos() { mostrarPagina('modelos'); }

// ========== FINANCIAMIENTO ==========
let planSeleccionado = null, metodoPagoSeleccionado = null, motoSeleccionadaParaFinanciamiento = null, anioModeloSeleccionado = '2025';
const planesFinanciamiento = { basico: { nombre: "Plan Básico", apartado: 150, cuotas: 12, interes: 0 }, premium: { nombre: "Plan Premium", apartado: 300, cuotas: 24, interes: 5 } };
const metodosPago = { transferencia: { nombre: "Transferencia Bancaria", icono: "🏦" }, movil: { nombre: "Pago Móvil", icono: "📱" }, efectivo: { nombre: "Efectivo", icono: "💵" }, tarjeta: { nombre: "Tarjeta", icono: "💳" } };

function irAFinanciamientoConMoto(motoId) { motoSeleccionadaParaFinanciamiento = motos[motoId]; mostrarPagina('financiamiento'); mostrarNotificacion(`Moto seleccionada: ${motoSeleccionadaParaFinanciamiento.nombre}`, 'exito'); }

function seleccionarPlan(plan) {
    planSeleccionado = plan;
    document.querySelectorAll('.financing-card.basic, .financing-card.premium').forEach(c => c.classList.remove('seleccionado'));
    document.querySelector(`.financing-card.${plan}`).classList.add('seleccionado');
    mostrarNotificacion(`Plan ${planesFinanciamiento[plan].nombre} seleccionado`, 'exito');
    if (metodoPagoSeleccionado && motoSeleccionadaParaFinanciamiento) mostrarResumenFinanciamiento();
}

function seleccionarMetodoPago(metodo) {
    metodoPagoSeleccionado = metodo;
    document.querySelectorAll('.payment-methods span').forEach(s => s.classList.remove('seleccionado'));
    event.target.closest('span').classList.add('seleccionado');
    mostrarNotificacion(`Método: ${metodosPago[metodo].nombre}`, 'exito');
    if (planSeleccionado && motoSeleccionadaParaFinanciamiento) mostrarResumenFinanciamiento();
}

function seleccionarAnioModelo(anio) {
    anioModeloSeleccionado = anio;
    document.querySelectorAll('.anio-btn-interno').forEach(btn => btn.classList.remove('active'));
    const btnSeleccionado = document.querySelector(`.anio-btn-interno[data-anio="${anio}"]`);
    if (btnSeleccionado) btnSeleccionado.classList.add('active');
    mostrarNotificacion(`Año seleccionado: Modelo ${anio}${anio==='2026'?' (+10%)':''}`, 'info');
    if (motoSeleccionadaParaFinanciamiento && planSeleccionado && metodoPagoSeleccionado) mostrarResumenFinanciamiento();
}

function mostrarResumenFinanciamiento() {
    if (!motoSeleccionadaParaFinanciamiento) { mostrarNotificacion('Selecciona una moto primero', 'warning'); return; }
    const planData = planesFinanciamiento[planSeleccionado], metodoData = metodosPago[metodoPagoSeleccionado];
    let precioBase = motoSeleccionadaParaFinanciamiento.precio, incrementoAnio = 0;
    if (anioModeloSeleccionado === '2026') { incrementoAnio = Math.round(precioBase * 0.10); precioBase = precioBase + incrementoAnio; }
    const montoApartado = planData.apartado, cuotasMensuales = Math.ceil((precioBase - montoApartado) / planData.cuotas);
    const imagenesModelos = { jaguar: "modelos/Jaguar.jpg", rex: "modelos/rextr250.jpg", fox: "modelos/fox.jpg", leon: "modelos/leon.jpg", r3x: "modelos/r3x.jpg", rex150: "modelos/rex150.jpg", tank3: "modelos/tank3.jpg", tankTr180: "modelos/tanktr180.jpg" };
    let motoId = ''; for (const id in motos) if (motos[id].nombre === motoSeleccionadaParaFinanciamiento.nombre) { motoId = id; break; }
    const imagenMoto = imagenesModelos[motoId] || 'modelos/default.jpg';
    const resumenHTML = `<div class="resumen-contenido">
        <div class="resumen-datos">
            <div class="resumen-item"><span><i class="fas fa-tag"></i> Precio base:</span><strong>$${motoSeleccionadaParaFinanciamiento.precio} USD</strong></div>
            ${anioModeloSeleccionado === '2026' ? `<div class="resumen-item incremento"><span><i class="fas fa-plus-circle"></i> Incremento modelo 2026:</span><strong>+$${incrementoAnio} USD (10%)</strong></div>` : ''}
            <div class="resumen-item precio-final"><span><i class="fas fa-money-bill-wave"></i> Precio final:</span><strong>$${precioBase} USD</strong></div>
            <div class="resumen-item"><span><i class="fas fa-file-alt"></i> Plan seleccionado:</span><strong>${planData.nombre}</strong></div>
            <div class="resumen-item"><span><i class="fas fa-hand-holding-usd"></i> Monto de apartado:</span><strong>$${planData.apartado} USD</strong></div>
            <div class="resumen-item"><span><i class="fas fa-calendar-alt"></i> Número de cuotas:</span><strong>${planData.cuotas} cuotas</strong></div>
            <div class="resumen-item"><span><i class="fas fa-calculator"></i> Valor de cada cuota:</span><strong>$${cuotasMensuales} USD</strong></div>
            <div class="resumen-item"><span><i class="fas fa-credit-card"></i> Método de pago:</span><strong>${metodoData.nombre} ${metodoData.icono}</strong></div>
            ${planData.interes > 0 ? `<div class="resumen-item"><span><i class="fas fa-percentage"></i> Interés aplicado:</span><strong>${planData.interes}%</strong></div>` : ''}
            <div class="resumen-item total"><span><i class="fas fa-check-circle"></i> Total a pagar:</span><strong>$${precioBase} USD</strong></div>
        </div>
        <div class="resumen-moto-card">
            <img src="${imagenMoto}" alt="${motoSeleccionadaParaFinanciamiento.nombre}" class="resumen-moto-img" onerror="this.src='modelos/default.jpg'">
            <div class="resumen-moto-info">
                <h4>${motoSeleccionadaParaFinanciamiento.nombre}</h4>
                <div class="resumen-moto-detalles">
                    <span><i class="fas fa-calendar"></i> Año: ${anioModeloSeleccionado}</span>
                    <span><i class="fas fa-tachometer-alt"></i> ${motoSeleccionadaParaFinanciamiento.cilindrada}</span>
                </div>
            </div>
        </div>
    </div>`;
    document.getElementById('resumen-contenido').innerHTML = resumenHTML; document.getElementById('financiamiento-resumen').style.display = 'block'; document.getElementById('financiamiento-resumen').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function confirmarFinanciamiento() {
    if (!motoSeleccionadaParaFinanciamiento) { mostrarNotificacion('Error: No hay una moto seleccionada', 'error'); return; }
    const planData = planesFinanciamiento[planSeleccionado], metodoData = metodosPago[metodoPagoSeleccionado];
    let precioBase = motoSeleccionadaParaFinanciamiento.precio, incrementoAnio = 0;
    if (anioModeloSeleccionado === '2026') { incrementoAnio = Math.round(precioBase * 0.10); precioBase = precioBase + incrementoAnio; }
    const fecha = new Date();
    const fechaApartado = fecha.toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    fecha.setDate(fecha.getDate() + 30);
    const fechaLimite = fecha.toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    const numeroFactura = 'FT-' + new Date().getFullYear() + '-' + Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    const montoApartado = planData.apartado, cuotasMensuales = Math.ceil((precioBase - montoApartado) / planData.cuotas), saldoPendiente = precioBase - montoApartado;
    const facturaHTML = `
        <div class="factura-linea"><span>📄 N° Factura:</span><strong>${numeroFactura}</strong></div>
        <div class="factura-linea"><span>📅 Fecha de apartado:</span><strong>${fechaApartado}</strong></div>
        <div class="factura-linea"><span>🏍️ Modelo:</span><strong>${motoSeleccionadaParaFinanciamiento.nombre}</strong></div>
        <div class="factura-linea"><span>📅 Año del modelo:</span><strong>${anioModeloSeleccionado}</strong></div>
        <div class="factura-linea"><span>⚡ Cilindrada:</span><strong>${motoSeleccionadaParaFinanciamiento.cilindrada}</strong></div>
        <div class="factura-linea"><span>💰 Precio base:</span><strong>$${motoSeleccionadaParaFinanciamiento.precio} USD</strong></div>
        ${anioModeloSeleccionado === '2026' ? `<div class="factura-linea" style="color: #e67e22;"><span>📈 Incremento modelo 2026 (10%):</span><strong>+$${incrementoAnio} USD</strong></div>` : ''}
        <div class="factura-linea"><span>💵 Precio final:</span><strong>$${precioBase} USD</strong></div>
        <div class="factura-linea"><span>📋 Plan seleccionado:</span><strong>${planData.nombre}</strong></div>
        <div class="factura-linea"><span>💳 Monto de apartado:</span><strong>$${montoApartado} USD</strong></div>
        <div class="factura-linea"><span>📊 Saldo pendiente:</span><strong>$${saldoPendiente} USD</strong></div>
        <div class="factura-linea"><span>📅 Número de cuotas:</span><strong>${planData.cuotas} cuotas</strong></div>
        <div class="factura-linea"><span>💲 Valor de cada cuota:</span><strong>$${cuotasMensuales} USD</strong></div>
        <div class="factura-linea"><span>💳 Método de pago:</span><strong>${metodoData.nombre} ${metodoData.icono}</strong></div>
        ${planData.interes > 0 ? `<div class="factura-linea"><span>📈 Interés aplicado:</span><strong>${planData.interes}% anual</strong></div>` : ''}
        <div class="factura-linea"><span>⏰ Fecha límite de pago del apartado:</span><strong>${fechaLimite}</strong></div>
        <div class="factura-linea total"><span>🎉 TOTAL A PAGAR:</span><strong>$${precioBase} USD</strong></div>
        <div class="factura-linea total"><span>✅ Estado:</span><strong style="color:#10b981">¡APARTADO EXITOSO! ✅</strong></div>
        <div class="factura-nota"><i class="fas fa-info-circle"></i><span>Presente esta factura al momento de retirar su moto. El saldo pendiente se cancela en ${planData.cuotas} cuotas.</span></div>
    `;
    document.getElementById('factura-contenido').innerHTML = facturaHTML; document.getElementById('financiamiento-resumen').style.display = 'none'; document.getElementById('factura-final').style.display = 'block'; mostrarNotificacion('¡Financiamiento aprobado! Factura generada exitosamente', 'exito'); document.getElementById('factura-final').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function cancelarFinanciamiento() { planSeleccionado = null; metodoPagoSeleccionado = null; document.getElementById('financiamiento-resumen').style.display = 'none'; document.querySelectorAll('.financing-card').forEach(c => c.classList.remove('seleccionado')); document.querySelectorAll('.payment-methods span').forEach(s => s.classList.remove('seleccionado')); mostrarNotificacion('Financiamiento cancelado', 'info'); }
function imprimirFactura() { window.print(); }
function regresarAlMenu() { planSeleccionado = null; metodoPagoSeleccionado = null; motoSeleccionadaParaFinanciamiento = null; document.getElementById('factura-final').style.display = 'none'; document.getElementById('financiamiento-resumen').style.display = 'none'; mostrarPagina('inicio'); mostrarNotificacion('Regresando al menú', 'info'); }

// ========== INICIALIZAR ==========
generarModelosGrid();

document.addEventListener('DOMContentLoaded', function() { 
    const btn2025 = document.querySelector('.anio-btn-interno[data-anio="2025"]'); 
    if (btn2025) btn2025.classList.add('active'); 
    anioModeloSeleccionado = '2025';
    
    const usuarioGuardado = localStorage.getItem('usuarioActual');
    if (usuarioGuardado) {
        mostrarOcultarAuditoria(usuarioGuardado);
    }
});

document.addEventListener('mousemove', function(e) { const imagePlatform = document.querySelector('.image-platform'); const motoImg = document.querySelector('.moto-float'); if (imagePlatform && motoImg && imagePlatform.matches(':hover')) { const rect = imagePlatform.getBoundingClientRect(); const x = e.clientX - rect.left; const y = e.clientY - rect.top; const centerX = rect.width / 2; const centerY = rect.height / 2; const rotateX = (y - centerY) / 20; const rotateY = (centerX - x) / 20; motoImg.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-${Math.abs(rotateX) * 2}px)`; } else if (motoImg) { motoImg.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0px)'; } });

console.log('✅ Sistema Motos Toro cargado exitosamente');